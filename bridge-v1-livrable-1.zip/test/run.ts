// Point d'entrée unique des tests du noyau Bridge v1.
// Lancé SANS l'option --test : node:test exécute alors les tests dans le processus courant,
// sans processus enfant ni thread. La commande exacte et ses permissions sont soumises à
// approbation avant toute exécution (voir le plan approuvé, section 8).

import "./mission/validation.test.ts";
import "./mission/json-strict.test.ts";
import "./mission/canonique.test.ts";
import "./mission/chemins.test.ts";
import "./mission/politique.test.ts";
import "./mission/exclusions.test.ts";
