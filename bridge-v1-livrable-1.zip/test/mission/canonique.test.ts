// Tests de serialiserCanonique : forme canonique, domaine fermé, comptage des nœuds, empreinte.

import { test } from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import reglesChemins from "../../config/regles-chemins.json" with { type: "json" };
import vecteurs from "../vecteurs/canonique.json" with { type: "json" };
import { analyserJsonStrict } from "../../src/mission/json-strict.ts";
import { NOEUDS_MAX_CANONIQUE, PROFONDEUR_MAX_CANONIQUE, serialiserCanonique } from "../../src/mission/canonique.ts";

interface VecteursCanonique {
  readonly sorties: ReadonlyArray<{ readonly nom: string; readonly entree: unknown; readonly sortie: string }>;
  readonly refus: ReadonlyArray<{ readonly nom: string; readonly entree: unknown; readonly sous_raison: string; readonly pointeur: string }>;
}

const V = vecteurs as unknown as VecteursCanonique;

// Empreinte de référence de la configuration par défaut : à figer après la première exécution
// approuvée (elle ne peut pas être calculée sans exécuter de code).
const EMPREINTE_REFERENCE_EXCLUSION_PAR_DEFAUT: string | null = null;

const FORME_CANONIQUE_EXCLUSION_PAR_DEFAUT = [
  '{"secrets":[',
  '{"id":"SEC-EXACT-SSH","type":"nom_exact","valeur":".ssh"},',
  '{"id":"SEC-EXACT-AWS","type":"nom_exact","valeur":".aws"},',
  '{"id":"SEC-EXACT-AZURE","type":"nom_exact","valeur":".azure"},',
  '{"id":"SEC-EXACT-GNUPG","type":"nom_exact","valeur":".gnupg"},',
  '{"id":"SEC-EXACT-KUBE","type":"nom_exact","valeur":".kube"},',
  '{"id":"SEC-EXACT-DOCKER","type":"nom_exact","valeur":".docker"},',
  '{"id":"SEC-EXACT-GIT","type":"nom_exact","valeur":".git"},',
  '{"id":"SEC-EXACT-ENV","type":"nom_exact","valeur":".env"},',
  '{"id":"SEC-EXACT-NPMRC","type":"nom_exact","valeur":".npmrc"},',
  '{"id":"SEC-EXACT-PYPIRC","type":"nom_exact","valeur":".pypirc"},',
  '{"id":"SEC-EXACT-NETRC","type":"nom_exact","valeur":".netrc"},',
  '{"id":"SEC-EXACT-NETRC-WIN","type":"nom_exact","valeur":"_netrc"},',
  '{"id":"SEC-EXACT-GIT-CREDENTIALS","type":"nom_exact","valeur":".git-credentials"},',
  '{"id":"SEC-EXACT-CREDENTIALS","type":"nom_exact","valeur":"credentials"},',
  '{"id":"SEC-EXACT-CREDENTIALS-JSON","type":"nom_exact","valeur":"credentials.json"},',
  '{"id":"SEC-EXACT-SECRETS","type":"nom_exact","valeur":"secrets"},',
  '{"id":"SEC-EXACT-SECRETS-JSON","type":"nom_exact","valeur":"secrets.json"},',
  '{"id":"SEC-EXACT-AUTH-JSON","type":"nom_exact","valeur":"auth.json"},',
  '{"id":"SEC-PRE-ENV","type":"prefixe","valeur":".env."},',
  '{"id":"SEC-PRE-ID-RSA","type":"prefixe","valeur":"id_rsa"},',
  '{"id":"SEC-PRE-ID-DSA","type":"prefixe","valeur":"id_dsa"},',
  '{"id":"SEC-PRE-ID-ECDSA","type":"prefixe","valeur":"id_ecdsa"},',
  '{"id":"SEC-PRE-ID-ED25519","type":"prefixe","valeur":"id_ed25519"},',
  '{"id":"SEC-SUF-PEM","type":"suffixe","valeur":".pem"},',
  '{"id":"SEC-SUF-KEY","type":"suffixe","valeur":".key"},',
  '{"id":"SEC-SUF-P12","type":"suffixe","valeur":".p12"},',
  '{"id":"SEC-SUF-PFX","type":"suffixe","valeur":".pfx"},',
  '{"id":"SEC-SUF-JKS","type":"suffixe","valeur":".jks"},',
  '{"id":"SEC-SUF-KEYSTORE","type":"suffixe","valeur":".keystore"},',
  '{"id":"SEC-SUF-KDBX","type":"suffixe","valeur":".kdbx"},',
  '{"id":"SEC-SUF-PPK","type":"suffixe","valeur":".ppk"}',
  '],"segments_interdits":[{"id":"INT-FASTCLIP","type":"contient","valeur":"fastclip"}],"version":"1"}',
].join("");

function sha256(texte: string): string {
  return "sha256:" + createHash("sha256").update(texte, "utf8").digest("hex");
}

function refusAttendu(valeur: unknown, sousRaison: string, pointeur: string, message: string): void {
  const r = serialiserCanonique(valeur);
  assert.equal(r.ok, false, message);
  if (!r.ok) {
    assert.equal(r.code, "NON_CANONISABLE", message);
    assert.equal(r.sous_raison, sousRaison, message);
    assert.equal(r.pointeur, pointeur, message);
    assert.equal(Object.hasOwn(r, "texte"), false, `${message} : aucune sérialisation partielle`);
  }
}

function texteAttendu(valeur: unknown, message: string): string {
  const r = serialiserCanonique(valeur);
  if (!r.ok) throw new Error(`${message} : refus inattendu ${r.sous_raison} ${r.pointeur}`);
  return r.texte;
}

test("canonique : vecteurs de sortie", () => {
  for (const v of V.sorties) assert.equal(texteAttendu(v.entree, v.nom), v.sortie, v.nom);
});

test("canonique : vecteurs de refus exprimables en JSON", () => {
  for (const v of V.refus) refusAttendu(v.entree, v.sous_raison, v.pointeur, v.nom);
});

test("canonique : l'ordre des propriétés est indifférent, l'ordre des tableaux ne l'est pas", () => {
  assert.equal(texteAttendu({ a: "1", b: { c: "2", d: "3" } }, "a"), texteAttendu({ b: { d: "3", c: "2" }, a: "1" }, "b"));
  assert.notEqual(texteAttendu(["a", "b"], "c"), texteAttendu(["b", "a"], "d"));
});

test("canonique : forme et empreinte de l'exclusion par défaut", () => {
  const texte = texteAttendu(reglesChemins.exclusion, "exclusion par défaut");
  assert.equal(texte, FORME_CANONIQUE_EXCLUSION_PAR_DEFAUT);
  const analyse = analyserJsonStrict(JSON.stringify(reglesChemins.exclusion));
  if (!analyse.ok) throw new Error("texte de l'exclusion refusé");
  assert.equal(texteAttendu(analyse.valeur, "exclusion analysée"), FORME_CANONIQUE_EXCLUSION_PAR_DEFAUT);
  const empreinte = sha256(texte);
  assert.ok(/^sha256:[0-9a-f]{64}$/u.test(empreinte));
  const reordonnee = {
    version: reglesChemins.exclusion.version,
    segments_interdits: reglesChemins.exclusion.segments_interdits.map((r) => ({ valeur: r.valeur, type: r.type, id: r.id })),
    secrets: reglesChemins.exclusion.secrets.map((r) => ({ valeur: r.valeur, id: r.id, type: r.type })),
  };
  assert.equal(sha256(texteAttendu(reordonnee, "réordonnée")), empreinte);
  if (EMPREINTE_REFERENCE_EXCLUSION_PAR_DEFAUT !== null) assert.equal(empreinte, EMPREINTE_REFERENCE_EXCLUSION_PAR_DEFAUT);
});

test("canonique : objets et tableaux non conformes", () => {
  let accesseurAppele = false;
  const avecAccesseur: Record<string, unknown> = {};
  Object.defineProperty(avecAccesseur, "a", {
    get() {
      accesseurAppele = true;
      return "x";
    },
    enumerable: true,
  });
  refusAttendu(avecAccesseur, "ACCESSEUR", "/a", "accesseur get");
  assert.equal(accesseurAppele, false, "l'accesseur n'a pas été appelé");

  const avecMutateur: Record<string, unknown> = {};
  Object.defineProperty(avecMutateur, "a", { set(_v: unknown) {}, enumerable: true });
  refusAttendu(avecMutateur, "ACCESSEUR", "/a", "mutateur seul");

  refusAttendu({ [Symbol("s")]: "x" }, "SYMBOLE", "", "propriété symbolique");

  const nonEnumerable: Record<string, unknown> = {};
  Object.defineProperty(nonEnumerable, "a", { value: "x", enumerable: false });
  refusAttendu(nonEnumerable, "NON_ENUMERABLE", "/a", "propriété non énumérable");

  class Instance {
    readonly a = "x";
  }
  refusAttendu(Object.create({}), "PROTOTYPE", "", "Object.create({})");
  refusAttendu(new Instance(), "PROTOTYPE", "", "instance de classe");
  refusAttendu(new Date(0), "PROTOTYPE", "", "Date");
  refusAttendu(new Map(), "PROTOTYPE", "", "Map");
  refusAttendu(/x/u, "PROTOTYPE", "", "RegExp");
  refusAttendu(new String("a"), "TYPE", "", "objet String");

  refusAttendu([, "a"], "TROU", "/0", "tableau creux");
  const tropLong: string[] = ["a"];
  tropLong.length = 3;
  refusAttendu(tropLong, "TROU", "/1", "length supérieur au nombre d'éléments");

  const avecPropriete = ["a"];
  Object.defineProperty(avecPropriete, "extra", { value: "x", enumerable: true });
  refusAttendu(avecPropriete, "PROPRIETE_TABLEAU", "/extra", "propriété supplémentaire sur un tableau");

  const avecSymbole = ["a"];
  Object.defineProperty(avecSymbole, Symbol("s"), { value: "x", enumerable: true });
  refusAttendu(avecSymbole, "SYMBOLE", "", "propriété symbolique sur un tableau");

  const indexAccesseur: string[] = [];
  Object.defineProperty(indexAccesseur, "0", { get: () => "x", enumerable: true, configurable: true });
  refusAttendu(indexAccesseur, "ACCESSEUR", "/0", "index défini par un accesseur");

  class Liste extends Array<string> {}
  refusAttendu(new Liste(), "PROTOTYPE", "", "sous-classe de Array");
  const prototypeChange = ["a"];
  Object.setPrototypeOf(prototypeChange, {});
  refusAttendu(prototypeChange, "PROTOTYPE", "", "tableau au prototype changé");
});

test("canonique : valeurs non admises", () => {
  refusAttendu({ a: undefined }, "TYPE", "/a", "undefined dans un objet");
  refusAttendu([undefined], "TYPE", "/0", "undefined dans un tableau");
  refusAttendu(Symbol("s"), "TYPE", "", "symbole");
  refusAttendu(() => "x", "TYPE", "", "fonction");
  refusAttendu(1n, "TYPE", "", "bigint");
  refusAttendu(1, "TYPE", "", "nombre");
  refusAttendu(false, "TYPE", "", "booléen");
  refusAttendu(null, "TYPE", "", "null");
});

test("canonique : références circulaires et partagées", () => {
  const boucle: Record<string, unknown> = {};
  boucle["self"] = boucle;
  refusAttendu(boucle, "CIRCULAIRE", "/self", "objet vers lui-même");
  const tableau: unknown[] = [];
  const conteneur = { a: tableau };
  tableau.push(conteneur);
  refusAttendu(conteneur, "CIRCULAIRE", "/a/0", "boucle à travers un tableau");
  const partage = { x: "1" };
  refusAttendu({ a: partage, b: partage }, "PARTAGE", "/b", "référence partagée");
});

test("canonique : structures acceptées", () => {
  const sansPrototype = Object.create(null) as Record<string, unknown>;
  sansPrototype["b"] = "1";
  sansPrototype["a"] = "2";
  assert.equal(texteAttendu(sansPrototype, "prototype null"), texteAttendu({ a: "2", b: "1" }, "objet ordinaire"));
  assert.equal(texteAttendu(Object.freeze({ a: Object.seal(["x"]) }), "gelé et scellé"), '{"a":["x"]}');
  const analyse = analyserJsonStrict('{"__proto__":"x","a":"y"}');
  if (!analyse.ok) throw new Error("texte refusé");
  assert.equal(texteAttendu(analyse.valeur, "__proto__ propre"), '{"__proto__":"x","a":"y"}');
});

test("canonique : profondeur", () => {
  assert.equal(PROFONDEUR_MAX_CANONIQUE, 32);
  const imbrique = (tableaux: number): unknown => {
    let v: unknown = "x";
    for (let i = 0; i < tableaux; i++) v = [v];
    return v;
  };
  assert.equal(texteAttendu(imbrique(31), "32 niveaux").length > 0, true);
  const pointeur33 = "/0".repeat(32);
  refusAttendu(imbrique(32), "PROFONDEUR", pointeur33, "33 niveaux");
});

test("canonique : comptage des nœuds", () => {
  assert.equal(NOEUDS_MAX_CANONIQUE, 10_000);
  const chaines = (n: number): string[] => new Array<string>(n).fill("s");
  const objet = (n: number): Record<string, string> => {
    const o: Record<string, string> = {};
    for (let i = 0; i < n; i++) o[`k${String(i).padStart(5, "0")}`] = "s";
    return o;
  };

  texteAttendu(chaines(9_999), "tableau de 9 999 chaînes : 10 000 nœuds");
  refusAttendu(chaines(10_000), "TAILLE", "/9999", "tableau de 10 000 chaînes : 10 001 nœuds");

  texteAttendu(objet(9_999), "objet à 9 999 propriétés : 10 000 nœuds");
  refusAttendu(objet(10_000), "TAILLE", "/k09999", "objet à 10 000 propriétés : 10 001 nœuds");

  texteAttendu({ a: chaines(4_998), b: objet(4_999) }, "mixte : 1 + 1 + 4 998 + 1 + 4 999 = 10 000");
  refusAttendu({ a: chaines(4_999), b: objet(4_999) }, "TAILLE", "/b/k04998", "mixte : 10 001");

  refusAttendu({ a: [], b: {}, c: chaines(9_997) }, "TAILLE", "/c/9996", "conteneurs vides comptés : 10 001");
  texteAttendu({ a: [], b: {}, c: chaines(9_996) }, "conteneurs vides comptés : 10 000");

  assert.equal(texteAttendu("seule", "chaîne racine"), '"seule"');
  assert.equal(texteAttendu({}, "objet racine vide"), "{}");

  const avecAccesseur: Record<string, unknown> = { b: chaines(10_001) };
  Object.defineProperty(avecAccesseur, "a", { get: () => "x", enumerable: true });
  refusAttendu(avecAccesseur, "ACCESSEUR", "/a", "accesseur détecté avant le comptage");
});
