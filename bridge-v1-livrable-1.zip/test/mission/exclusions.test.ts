// Tests de verifierReglesPolitiqueTexte et verifierReglesPolitique : objet fermé, recopie à
// l'identique, clés dupliquées, structures non conformes.

import { test } from "node:test";
import assert from "node:assert/strict";
import profils from "../../config/profils.json" with { type: "json" };
import reglesChemins from "../../config/regles-chemins.json" with { type: "json" };
import vecteursExclusions from "../vecteurs/exclusions.json" with { type: "json" };
import vecteursMissions from "../vecteurs/missions.json" with { type: "json" };
import { calculerPolitique, type Politique } from "../../src/mission/politique.ts";
import { VALEURS_FIXES_EXCLUSIONS, verifierReglesPolitique, verifierReglesPolitiqueTexte } from "../../src/mission/regles-politique.ts";

type Cle = string | number;

interface Operation {
  readonly type: "definir" | "supprimer" | "pousser" | "echanger" | "reordonner" | "remplacer_racine";
  readonly chemin: readonly Cle[];
  readonly valeur?: unknown;
  readonly i?: number;
  readonly j?: number;
}

const VE = (vecteursExclusions as unknown as {
  readonly vecteurs: ReadonlyArray<{ readonly nom: string; readonly operations: readonly Operation[]; readonly attendu: string }>;
}).vecteurs;

const PROPRIETES = [
  "version",
  "portee",
  "semantique",
  "regles",
  "forme_canonique_regles",
  "type_entree_indetermine",
  "comportement_si_inapplicable",
  "appliquee_par",
  "statut_dans_le_noyau",
] as const;

function copie<T>(v: T): T {
  return JSON.parse(JSON.stringify(v)) as T;
}

function configuration(): Record<string, unknown> {
  return { profils: copie(profils), regles_chemins: copie(reglesChemins) };
}

function politiqueDeReference(conf: unknown = configuration()): Politique {
  const r = calculerPolitique(copie(vecteursMissions.base), vecteursMissions.contexte, conf);
  if (!r.ok) throw new Error(`politique de référence refusée : ${r.code}`);
  return r.politique;
}

function naviguer(racine: unknown, chemin: readonly Cle[]): Record<string, unknown> {
  let cible: unknown = racine;
  for (const cle of chemin) cible = (cible as Record<string, unknown>)[String(cle)];
  return cible as Record<string, unknown>;
}

function appliquer(racine: Record<string, unknown>, op: Operation): unknown {
  if (op.type === "remplacer_racine") return op.valeur;
  if (op.type === "pousser") {
    (naviguer(racine, op.chemin) as unknown as unknown[]).push(op.valeur);
    return racine;
  }
  if (op.type === "echanger") {
    const t = naviguer(racine, op.chemin) as unknown as unknown[];
    const i = op.i ?? 0;
    const j = op.j ?? 1;
    const x = t[i];
    t[i] = t[j];
    t[j] = x;
    return racine;
  }
  const parent = naviguer(racine, op.chemin.slice(0, -1));
  const derniere = String(op.chemin[op.chemin.length - 1]);
  if (op.type === "reordonner") {
    const objet = parent[derniere] as Record<string, unknown>;
    const inverse: Record<string, unknown> = {};
    for (const cle of Object.keys(objet).reverse()) inverse[cle] = objet[cle];
    parent[derniere] = inverse;
    return racine;
  }
  if (op.type === "definir") parent[derniere] = op.valeur;
  else if (Array.isArray(parent)) parent.splice(Number(derniere), 1);
  else delete parent[derniere];
  return racine;
}

function codeTexte(texte: unknown, conf: unknown = configuration()): string {
  const r = verifierReglesPolitiqueTexte(texte, conf);
  return r.ok ? "ok" : r.code;
}

test("exclusions : les règles de la politique sont une copie exacte de la configuration", () => {
  const p = politiqueDeReference();
  const objet = p.exclusions_lecture_obligatoires as unknown as Record<string, unknown>;
  assert.deepEqual(Object.keys(objet), [...PROPRIETES]);
  assert.deepEqual(Object.keys(objet["regles"] as Record<string, unknown>), ["version", "segments_interdits", "secrets"]);
  assert.deepEqual(objet["regles"], reglesChemins.exclusion);
});

test("exclusions : une configuration modifiée se retrouve à l'identique dans la sortie", () => {
  const conf = configuration();
  const exclusion = naviguer(conf, ["regles_chemins", "exclusion"]);
  (exclusion["secrets"] as unknown[]).push({ id: "SEC-EXACT-AUTRE", type: "nom_exact", valeur: ".autre" });
  const secrets = exclusion["secrets"] as unknown[];
  const premier = secrets[0];
  secrets[0] = secrets[1];
  secrets[1] = premier;
  const p = politiqueDeReference(conf);
  assert.deepEqual(p.exclusions_lecture_obligatoires.regles, exclusion);
  assert.equal(codeTexte(JSON.stringify(p), conf), "ok");
  assert.equal(codeTexte(JSON.stringify(p)), "REGLES_EXCLUSION_DIFFERENTES", "comparée à la configuration d'origine");
});

test("exclusions : vecteurs de mutation", () => {
  for (const v of VE) {
    let politique: unknown = copie(politiqueDeReference()) as unknown as Record<string, unknown>;
    for (const op of v.operations) politique = appliquer(politique as Record<string, unknown>, op);
    assert.equal(codeTexte(JSON.stringify(politique)), v.attendu, v.nom);
  }
});

test("exclusions : chaque propriété manquante est refusée", () => {
  for (const cle of PROPRIETES) {
    const p = copie(politiqueDeReference()) as unknown as Record<string, unknown>;
    delete (p["exclusions_lecture_obligatoires"] as Record<string, unknown>)[cle];
    assert.equal(codeTexte(JSON.stringify(p)), "REGLES_EXCLUSION_INVALIDES", cle);
  }
});

test("exclusions : chaque valeur fixe modifiée est refusée", () => {
  for (const [cle, valeur] of Object.entries(VALEURS_FIXES_EXCLUSIONS)) {
    const p = copie(politiqueDeReference()) as unknown as Record<string, unknown>;
    (p["exclusions_lecture_obligatoires"] as Record<string, unknown>)[cle] = `${valeur}_modifiee`;
    assert.equal(codeTexte(JSON.stringify(p)), "REGLES_EXCLUSION_INVALIDES", cle);
  }
  assert.equal(Object.keys(VALEURS_FIXES_EXCLUSIONS).length, 8);
});

test("exclusions : clés dupliquées dans le texte de la politique", () => {
  const p = politiqueDeReference();
  const texte = JSON.stringify(p);
  const exclusions = JSON.stringify(p.exclusions_lecture_obligatoires);
  const regles = JSON.stringify(p.exclusions_lecture_obligatoires.regles);

  const regleDouble = texte.replace(`"regles":${regles}`, `"regles":${regles},"regles":${regles}`);
  assert.notEqual(regleDouble, texte);
  assert.equal(codeTexte(regleDouble), "POLITIQUE_JSON_INVALIDE");

  const exclusionsDouble = texte.replace(
    `"exclusions_lecture_obligatoires":${exclusions}`,
    `"exclusions_lecture_obligatoires":${exclusions.replace('"REFUS"', '"IGNORER"')},"exclusions_lecture_obligatoires":${exclusions}`,
  );
  assert.notEqual(exclusionsDouble, texte);
  const r = verifierReglesPolitiqueTexte(exclusionsDouble, configuration());
  assert.equal(r.ok ? "ok" : r.code, "POLITIQUE_JSON_INVALIDE", "jamais ok malgré la dernière occurrence conforme");
  if (!r.ok) assert.equal(r.detail["sous_raison"], "CLE_DUPLIQUEE");

  const idDouble = texte.replace('{"id":"INT-FASTCLIP"', '{"id":"INT-FASTCLIP","id":"INT-FASTCLIP"');
  assert.notEqual(idDouble, texte);
  assert.equal(codeTexte(idDouble), "POLITIQUE_JSON_INVALIDE");

  const protoPropre = texte.replace('"exclusions_lecture_obligatoires":{', '"exclusions_lecture_obligatoires":{"__proto__":"x",');
  assert.notEqual(protoPropre, texte);
  assert.equal(codeTexte(protoPropre), "REGLES_EXCLUSION_INVALIDES", "propriété propre __proto__ en plus");
});

test("exclusions : le texte et l'objet analysé donnent le même résultat", () => {
  const p = politiqueDeReference();
  assert.equal(codeTexte(JSON.stringify(p)), "ok");
  const r = verifierReglesPolitique(JSON.parse(JSON.stringify(p)), configuration());
  assert.equal(r.ok, true);
});

test("exclusions : la politique doit être fournie sous forme de texte", () => {
  const r = verifierReglesPolitiqueTexte(politiqueDeReference(), configuration());
  assert.equal(r.ok ? "ok" : r.code, "POLITIQUE_JSON_INVALIDE");
  if (!r.ok) assert.equal(r.detail["sous_raison"], "TYPE");
  assert.equal(codeTexte("{"), "POLITIQUE_JSON_INVALIDE");
});

test("exclusions : structures non conformes passées directement", () => {
  const avecAccesseur = copie(politiqueDeReference()) as unknown as Record<string, unknown>;
  const objet = avecAccesseur["exclusions_lecture_obligatoires"] as Record<string, unknown>;
  const portee = objet["portee"];
  delete objet["portee"];
  Object.defineProperty(objet, "portee", { get: () => portee, enumerable: true });
  const r1 = verifierReglesPolitique(avecAccesseur, configuration());
  assert.equal(r1.ok ? "ok" : r1.code, "REGLES_EXCLUSION_INVALIDES", "accesseur");

  class Exclusions {
    readonly version = "2";
  }
  const avecClasse = copie(politiqueDeReference()) as unknown as Record<string, unknown>;
  avecClasse["exclusions_lecture_obligatoires"] = new Exclusions();
  const r2 = verifierReglesPolitique(avecClasse, configuration());
  assert.equal(r2.ok ? "ok" : r2.code, "REGLES_EXCLUSION_INVALIDES", "instance de classe");

  const accesseurRacine: Record<string, unknown> = {};
  Object.defineProperty(accesseurRacine, "exclusions_lecture_obligatoires", { get: () => ({}), enumerable: true });
  const r3 = verifierReglesPolitique(accesseurRacine, configuration());
  assert.equal(r3.ok ? "ok" : r3.code, "REGLES_EXCLUSION_INVALIDES", "accesseur sur la politique");
});

test("exclusions : configuration de référence invalide", () => {
  const conf = configuration();
  delete naviguer(conf, ["regles_chemins", "exclusion"])["secrets"];
  assert.equal(codeTexte(JSON.stringify(politiqueDeReference()), conf), "CONFIGURATION_INVALIDE");
});
