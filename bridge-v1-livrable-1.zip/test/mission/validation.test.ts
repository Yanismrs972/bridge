// Tests du validateur fermé et des schémas du noyau.

import { test } from "node:test";
import assert from "node:assert/strict";
import schemaContexte from "../../src/mission/schemas/contexte.schema.json" with { type: "json" };
import schemaExclusionsLecture from "../../src/mission/schemas/exclusions-lecture.schema.json" with { type: "json" };
import schemaMission from "../../src/mission/schemas/mission.schema.json" with { type: "json" };
import schemaPolitique from "../../src/mission/schemas/politique.schema.json" with { type: "json" };
import schemaProfils from "../../src/mission/schemas/profils.schema.json" with { type: "json" };
import schemaReglesChemins from "../../src/mission/schemas/regles-chemins.schema.json" with { type: "json" };
import schemaReglesExclusion from "../../src/mission/schemas/regles-exclusion.schema.json" with { type: "json" };
import { valider, verifierSchema } from "../../src/mission/validation.ts";
import { verifierSchemasInternes } from "../../src/mission/politique.ts";

function sansDialecte(schema: unknown): Record<string, unknown> {
  const copie = JSON.parse(JSON.stringify(schema)) as Record<string, unknown>;
  delete copie["$schema"];
  return copie;
}

function propriete(objet: unknown, ...chemin: string[]): unknown {
  let cible: unknown = objet;
  for (const cle of chemin) cible = (cible as Record<string, unknown>)[cle];
  return cible;
}

test("validation : tous les schémas du noyau respectent le sous-ensemble fermé", () => {
  const schemas: ReadonlyArray<readonly [string, unknown]> = [
    ["mission", schemaMission],
    ["contexte", schemaContexte],
    ["profils", schemaProfils],
    ["regles-chemins", schemaReglesChemins],
    ["regles-exclusion", schemaReglesExclusion],
    ["exclusions-lecture", schemaExclusionsLecture],
    ["politique", schemaPolitique],
  ];
  for (const [nom, schema] of schemas) assert.equal(verifierSchema(schema), null, nom);
  assert.equal(verifierSchemasInternes(), null);
});

test("validation : les sous-schémas imbriqués sont des copies exactes des schémas autonomes", () => {
  assert.deepEqual(propriete(schemaReglesChemins, "properties", "exclusion"), sansDialecte(schemaReglesExclusion));
  assert.deepEqual(propriete(schemaExclusionsLecture, "properties", "regles"), sansDialecte(schemaReglesExclusion));
  assert.deepEqual(propriete(schemaPolitique, "properties", "exclusions_lecture_obligatoires"), sansDialecte(schemaExclusionsLecture));
});

test("validation : tout mot-clé non pris en charge est refusé", () => {
  const motsCles: ReadonlyArray<readonly [string, unknown]> = [
    ["$ref", "#/a"],
    ["anyOf", [{ type: "string", maxLength: 1 }]],
    ["oneOf", [{ type: "string", maxLength: 1 }]],
    ["allOf", [{ type: "string", maxLength: 1 }]],
    ["not", { type: "string", maxLength: 1 }],
    ["if", { type: "string", maxLength: 1 }],
    ["format", "email"],
    ["patternProperties", {}],
    ["default", "x"],
    ["uniqueItems", true],
    ["$id", "x"],
  ];
  for (const [cle, valeur] of motsCles) {
    const schema: Record<string, unknown> = { type: "string", maxLength: 5 };
    schema[cle] = valeur;
    const e = verifierSchema(schema);
    assert.equal(e?.raison, "SCHEMA_MOT_CLE_NON_PRIS_EN_CHARGE", cle);
  }
});

test("validation : règles imposées aux schémas", () => {
  assert.equal(verifierSchema({ type: "object", properties: {}, additionalProperties: true })?.raison, "SCHEMA_OBJET_NON_FERME");
  assert.equal(verifierSchema({ type: "object", properties: {} })?.raison, "SCHEMA_OBJET_NON_FERME");
  assert.equal(verifierSchema({ type: "string" })?.raison, "SCHEMA_CHAINE_NON_BORNEE");
  assert.equal(verifierSchema({ type: "array", items: { type: "string", maxLength: 1 } })?.raison, "SCHEMA_TABLEAU_NON_BORNE");
  assert.equal(verifierSchema({ type: "array", maxItems: 1 })?.raison, "SCHEMA_ITEMS_ABSENT");
  assert.equal(verifierSchema({ maxLength: 1 })?.raison, "SCHEMA_TYPE_INVALIDE");
  assert.equal(verifierSchema({ type: "string", maxLength: 1, pattern: "(" })?.raison, "SCHEMA_MOTIF_INVALIDE");
  assert.equal(verifierSchema({ $schema: "http://json-schema.org/draft-07/schema#", type: "boolean" })?.raison, "SCHEMA_DIALECTE_INVALIDE");
  assert.equal(verifierSchema({ type: "boolean", maxLength: 1 })?.raison, "SCHEMA_MOT_CLE_INCOHERENT");
  assert.equal(verifierSchema({ type: "object", properties: {}, additionalProperties: false, required: ["x"] })?.raison, "SCHEMA_REQUIRED_INVALIDE");
});

test("validation : erreurs de valeur", () => {
  const schema = {
    type: "object",
    additionalProperties: false,
    required: ["a"],
    properties: {
      a: { type: "string", minLength: 1, maxLength: 2, pattern: "^[a-z\u{1F600}]+$" },
      n: { type: "integer", minimum: 1, maximum: 3 },
      t: { type: "array", minItems: 1, maxItems: 2, items: { type: "string", maxLength: 1 } },
      e: { type: "string", enum: ["x", "y"], maxLength: 1 },
    },
  };
  assert.equal(verifierSchema(schema), null);
  assert.equal(valider(schema, { a: "ab" }), null);
  assert.equal(valider(schema, { a: "\u{1F600}" }), null, "longueur en points de code");
  assert.deepEqual(valider(schema, { a: "ab", z: 1 }), { pointeur: "/z", raison: "CHAMP_NON_PREVU" });
  assert.deepEqual(valider(schema, {}), { pointeur: "/a", raison: "CHAMP_MANQUANT" });
  assert.deepEqual(valider(schema, { a: 1 }), { pointeur: "/a", raison: "TYPE" });
  assert.deepEqual(valider(schema, { a: "abc" }), { pointeur: "/a", raison: "LONGUEUR" });
  assert.deepEqual(valider(schema, { a: "A" }), { pointeur: "/a", raison: "MOTIF" });
  assert.deepEqual(valider(schema, { a: "a", n: 4 }), { pointeur: "/n", raison: "BORNE" });
  assert.deepEqual(valider(schema, { a: "a", n: 1.5 }), { pointeur: "/n", raison: "TYPE" });
  assert.deepEqual(valider(schema, { a: "a", t: [] }), { pointeur: "/t", raison: "TAILLE_TABLEAU" });
  assert.deepEqual(valider(schema, { a: "a", t: ["xx"] }), { pointeur: "/t/0", raison: "LONGUEUR" });
  assert.deepEqual(valider(schema, { a: "a", e: "z" }), { pointeur: "/e", raison: "VALEUR_HORS_LISTE" });
  assert.deepEqual(valider(schema, []), { pointeur: "", raison: "TYPE" });
});
