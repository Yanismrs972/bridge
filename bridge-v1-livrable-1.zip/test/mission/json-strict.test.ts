// Tests de analyserJsonStrict : grammaire stricte, clés dupliquées, limites.

import { test } from "node:test";
import assert from "node:assert/strict";
import vecteurs from "../vecteurs/json-strict.json" with { type: "json" };
import { analyserJsonStrict, NOEUDS_MAX_JSON, PROFONDEUR_MAX_JSON, TAILLE_TEXTE_MAX } from "../../src/mission/json-strict.ts";

interface VecteurJson {
  readonly nom: string;
  readonly texte: string;
  readonly attendu: { readonly ok: boolean; readonly sous_raison?: string; readonly pointeur?: string };
}

const V = (vecteurs as unknown as { readonly vecteurs: readonly VecteurJson[] }).vecteurs;

test("json-strict : vecteurs", () => {
  for (const v of V) {
    const r = analyserJsonStrict(v.texte);
    assert.equal(r.ok, v.attendu.ok, v.nom);
    if (!r.ok) {
      assert.equal(r.code, "JSON_INVALIDE", v.nom);
      if (v.attendu.sous_raison !== undefined) assert.equal(r.sous_raison, v.attendu.sous_raison, v.nom);
      if (v.attendu.pointeur !== undefined) assert.equal(r.pointeur, v.attendu.pointeur, v.nom);
    }
  }
});

test("json-strict : la valeur acceptée est celle de JSON.parse", () => {
  const texte = '{"b":[1,"x",{"c":null}],"a":true}';
  const r = analyserJsonStrict(texte);
  if (!r.ok) assert.fail("texte valide refusé");
  else assert.deepEqual(r.valeur, JSON.parse(texte));
});

test("json-strict : une entrée qui n'est pas une chaîne est refusée", () => {
  const r = analyserJsonStrict({ a: "1" });
  assert.equal(r.ok, false);
  if (!r.ok) assert.equal(r.sous_raison, "TYPE");
});

test("json-strict : profondeur", () => {
  assert.equal(PROFONDEUR_MAX_JSON, 32);
  const imbrique = (n: number): string => "[".repeat(n - 1) + '"x"' + "]".repeat(n - 1);
  assert.equal(analyserJsonStrict(imbrique(32)).ok, true, "32 niveaux acceptés");
  const r = analyserJsonStrict(imbrique(33));
  assert.equal(r.ok, false);
  if (!r.ok) assert.equal(r.sous_raison, "PROFONDEUR");
});

test("json-strict : taille du texte", () => {
  assert.equal(TAILLE_TEXTE_MAX, 1_048_576);
  const limite = '"' + "a".repeat(TAILLE_TEXTE_MAX - 2) + '"';
  assert.equal(analyserJsonStrict(limite).ok, true);
  const r = analyserJsonStrict(limite + " ");
  assert.equal(r.ok, false);
  if (!r.ok) assert.equal(r.sous_raison, "TAILLE_TEXTE");
});

test("json-strict : comptage des nœuds (les nombres comptent)", () => {
  assert.equal(NOEUDS_MAX_JSON, 10_000);
  const tableau = (n: number): string => "[" + new Array<string>(n).fill("1").join(",") + "]";
  assert.equal(analyserJsonStrict(tableau(9_999)).ok, true, "1 + 9 999 = 10 000 nœuds");
  const r = analyserJsonStrict(tableau(10_000));
  assert.equal(r.ok, false);
  if (!r.ok) {
    assert.equal(r.sous_raison, "TAILLE");
    assert.equal(r.pointeur, "/9999");
  }
  assert.equal(analyserJsonStrict("{}").ok, true, "objet vide : 1 nœud");
});
