// Déclarations minimales des trois seuls modules Node autorisés, et uniquement dans test/.
// Aucun @types/node n'est utilisé : tout autre module Node fait échouer tsc.

declare module "node:test" {
  export function test(nom: string, fn: () => void | Promise<void>): Promise<void>;
}

declare module "node:assert/strict" {
  interface AssertStrict {
    (valeur: unknown, message?: string): void;
    ok(valeur: unknown, message?: string): void;
    equal(reel: unknown, attendu: unknown, message?: string): void;
    notEqual(reel: unknown, attendu: unknown, message?: string): void;
    deepEqual(reel: unknown, attendu: unknown, message?: string): void;
    notDeepEqual(reel: unknown, attendu: unknown, message?: string): void;
    fail(message?: string): never;
  }
  const assert: AssertStrict;
  export default assert;
}

declare module "node:crypto" {
  interface Empreinte {
    update(donnees: string, encodage: "utf8"): Empreinte;
    digest(encodage: "hex"): string;
  }
  export function createHash(algorithme: "sha256"): Empreinte;
}
