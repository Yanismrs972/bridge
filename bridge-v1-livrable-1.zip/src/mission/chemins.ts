// Règles de chemins de Bridge v1 : syntaxe lexicale, règles d'exclusion et evaluerChemin.
//
// Toutes les règles de ce module sont LEXICALES. Elles ne détectent ni les liens symboliques, ni
// les jonctions, ni les noms courts 8.3 réels, ni aucune redirection physique : ces contrôles
// relèvent du futur orchestrateur, avant tout accès réel aux fichiers.
//
// evaluerChemin est la fonction UNIQUE d'évaluation : le noyau (contrôle du périmètre) et le futur
// orchestrateur (énumération et copie) l'importent telle quelle, sans réimplémentation.

import schemaReglesExclusion from "./schemas/regles-exclusion.schema.json" with { type: "json" };
import { contientSurrogateIsolee } from "./canonique.ts";
import { valider, verifierSchema } from "./validation.ts";

export const LONGUEUR_MAX_CHEMIN = 240;
export const LONGUEUR_MAX_SEGMENT = 255;

const CARACTERES_INTERDITS: ReadonlySet<string> = new Set(["<", ">", ":", '"', "|", "?", "*", "/", "\\"]);

const NOMS_RESERVES: ReadonlySet<string> = new Set([
  "CON",
  "PRN",
  "AUX",
  "NUL",
  "COM0",
  "COM1",
  "COM2",
  "COM3",
  "COM4",
  "COM5",
  "COM6",
  "COM7",
  "COM8",
  "COM9",
  "LPT0",
  "LPT1",
  "LPT2",
  "LPT3",
  "LPT4",
  "LPT5",
  "LPT6",
  "LPT7",
  "LPT8",
  "LPT9",
  "COM\u00b9",
  "COM\u00b2",
  "COM\u00b3",
  "LPT\u00b9",
  "LPT\u00b2",
  "LPT\u00b3",
  "CONIN$",
  "CONOUT$",
]);

// ---------------------------------------------------------------------------------------------
// Types des règles d'exclusion
// ---------------------------------------------------------------------------------------------

export type TypeRegleSecret = "nom_exact" | "prefixe" | "suffixe";

export interface RegleInterdite {
  readonly id: string;
  readonly type: "contient";
  readonly valeur: string;
}

export interface RegleSecret {
  readonly id: string;
  readonly type: TypeRegleSecret;
  readonly valeur: string;
}

export interface ReglesExclusion {
  readonly version: "1";
  readonly segments_interdits: readonly RegleInterdite[];
  readonly secrets: readonly RegleSecret[];
}

export type CategorieExclusion = "interdit" | "secret";

export interface Correspondance {
  readonly index_segment: number;
  readonly categorie: CategorieExclusion;
  readonly id: string;
}

export interface RegleDesignee {
  readonly categorie: CategorieExclusion;
  readonly id: string;
}

export type ResultatEvaluation =
  | { readonly statut: "autorise"; readonly chemin_normalise: string }
  | {
      readonly statut: "invalide";
      readonly code: "CHEMIN_INVALIDE";
      readonly sous_regle: string;
      readonly index_segment: number | null;
    }
  | {
      readonly statut: "erreur_regles";
      readonly code: "REGLES_EXCLUSION_INVALIDES";
      readonly detail: { readonly raison: string; readonly pointeur: string };
    }
  | {
      readonly statut: "exclu";
      readonly code: "CHEMIN_INTERDIT" | "CHEMIN_SECRET";
      readonly categorie: CategorieExclusion;
      readonly racine_exclusion: string;
      readonly index_racine: number;
      readonly regle_racine: RegleDesignee;
      readonly regle_code: RegleDesignee;
      readonly correspondances: readonly Correspondance[];
    };

// ---------------------------------------------------------------------------------------------
// Syntaxe des segments et des chemins relatifs
// ---------------------------------------------------------------------------------------------

function estCaractereControle(code: number): boolean {
  return code <= 0x1f || code === 0x7f || (code >= 0x80 && code <= 0x9f);
}

function estNomReserve(segment: string): boolean {
  const base = (segment.split(".")[0] ?? "").replace(/ +$/u, "").toUpperCase();
  return NOMS_RESERVES.has(base);
}

/** Renvoie la sous-règle violée par un segment, ou null si le segment est valide. */
export function validerSegment(segment: string): string | null {
  if (segment.length === 0) return "SEGMENT_VIDE";
  if (segment === "." || segment === "..") return "SEGMENT_POINT";
  if (segment.length > LONGUEUR_MAX_SEGMENT) return "SEGMENT_TROP_LONG";
  if (contientSurrogateIsolee(segment)) return "UNICODE_INVALIDE";
  if (segment.normalize("NFC") !== segment) return "NON_NFC";
  for (let i = 0; i < segment.length; i++) {
    if (estCaractereControle(segment.charCodeAt(i))) return "CARACTERE_CONTROLE";
    if (CARACTERES_INTERDITS.has(segment.charAt(i))) return "CARACTERE_INTERDIT";
  }
  if (segment.startsWith(" ")) return "ESPACE_DEBUT";
  if (segment.endsWith(" ")) return "ESPACE_FIN";
  if (segment.endsWith(".")) return "POINT_FINAL";
  if (/~[0-9]/u.test(segment)) return "NOM_COURT_8_3";
  if (estNomReserve(segment)) return "NOM_RESERVE";
  return null;
}

export type AnalyseChemin =
  | { readonly ok: true; readonly segments: readonly string[]; readonly normalise: string }
  | { readonly ok: false; readonly sous_regle: string; readonly index_segment: number | null };

/** Analyse lexicale d'un chemin relatif. « \ » est normalisé en « / ». Rien n'est résolu. */
export function analyserCheminRelatif(chemin: string): AnalyseChemin {
  if (chemin.length === 0) return { ok: false, sous_regle: "CHEMIN_VIDE", index_segment: null };
  const normalise = chemin.replace(/\\/g, "/");
  if (normalise.startsWith("/")) return { ok: false, sous_regle: "SEPARATEUR_DEBUT", index_segment: null };
  if (normalise.endsWith("/")) return { ok: false, sous_regle: "SEPARATEUR_FIN", index_segment: null };
  const segments = normalise.split("/");
  for (let i = 0; i < segments.length; i++) {
    const e = validerSegment(segments[i] ?? "");
    if (e !== null) return { ok: false, sous_regle: e, index_segment: i };
  }
  if (normalise.length > LONGUEUR_MAX_CHEMIN) return { ok: false, sous_regle: "CHEMIN_TROP_LONG", index_segment: null };
  return { ok: true, segments, normalise };
}

// ---------------------------------------------------------------------------------------------
// Racines Windows absolues
// ---------------------------------------------------------------------------------------------

export interface RacineAnalysee {
  readonly lecteur: string;
  readonly segments: readonly string[];
}

export type AnalyseRacine = { readonly ok: true; readonly racine: RacineAnalysee } | { readonly ok: false; readonly raison: string };

/** Racine de la forme X:\seg\seg… uniquement. UNC, \\?\, \\.\, racine nue, « . » et « .. » refusés. */
export function analyserRacine(racine: string): AnalyseRacine {
  if (racine.length > LONGUEUR_MAX_CHEMIN) return { ok: false, raison: "RACINE_TROP_LONGUE" };
  if (racine.startsWith("\\\\")) return { ok: false, raison: "RACINE_UNC_OU_PREFIXE" };
  if (!/^[A-Za-z]:\\/u.test(racine)) return { ok: false, raison: "RACINE_FORME_INVALIDE" };
  if (racine.includes("/")) return { ok: false, raison: "RACINE_SEPARATEUR_INVALIDE" };
  const reste = racine.slice(3);
  if (reste.length === 0) return { ok: false, raison: "RACINE_LECTEUR_NUE" };
  const segments = reste.split("\\");
  for (const segment of segments) {
    const e = validerSegment(segment);
    if (e !== null) return { ok: false, raison: `RACINE_SEGMENT_INVALIDE:${e}` };
  }
  return { ok: true, racine: { lecteur: racine.charAt(0), segments } };
}

// ---------------------------------------------------------------------------------------------
// Validation des règles d'exclusion (format fermé)
// ---------------------------------------------------------------------------------------------

export type VerificationRegles =
  | { readonly ok: true; readonly regles: ReglesExclusion }
  | { readonly ok: false; readonly raison: string; readonly pointeur: string };

function verifierValeurRegle(type: string, valeur: string): string | null {
  if (contientSurrogateIsolee(valeur)) return "VALEUR_UNICODE_INVALIDE";
  if (valeur.normalize("NFC") !== valeur) return "VALEUR_NON_NFC";
  if (valeur === "." || valeur === "..") return "VALEUR_POINT";
  for (let i = 0; i < valeur.length; i++) {
    if (estCaractereControle(valeur.charCodeAt(i))) return "VALEUR_CARACTERE_CONTROLE";
    if (CARACTERES_INTERDITS.has(valeur.charAt(i))) return "VALEUR_CARACTERE_INTERDIT";
  }
  if (type === "nom_exact") {
    const e = validerSegment(valeur);
    return e === null ? null : `VALEUR_SEGMENT_INVALIDE:${e}`;
  }
  if (type === "prefixe") return valeur.startsWith(" ") ? "VALEUR_ESPACE_DEBUT" : null;
  if (type === "suffixe") {
    if (valeur.endsWith(".")) return "VALEUR_POINT_FINAL";
    if (valeur.endsWith(" ")) return "VALEUR_ESPACE_FIN";
    return null;
  }
  if (type === "contient") {
    if (valeur.startsWith(" ")) return "VALEUR_ESPACE_DEBUT";
    if (valeur.endsWith(" ")) return "VALEUR_ESPACE_FIN";
    return null;
  }
  return "TYPE_INCONNU";
}

/** Valide un objet de règles d'exclusion. Aucune valeur par défaut, aucune reconstruction. */
export function verifierReglesExclusion(regles: unknown): VerificationRegles {
  const meta = verifierSchema(schemaReglesExclusion);
  if (meta !== null) return { ok: false, raison: `SCHEMA_INTERNE:${meta.raison}`, pointeur: meta.pointeur };
  const e = valider(schemaReglesExclusion, regles);
  if (e !== null) return { ok: false, raison: e.raison, pointeur: e.pointeur };
  const r = regles as ReglesExclusion;
  const ids = new Set<string>();
  const couples = new Set<string>();
  const parcours: ReadonlyArray<readonly [string, readonly (RegleInterdite | RegleSecret)[]]> = [
    ["segments_interdits", r.segments_interdits],
    ["secrets", r.secrets],
  ];
  for (const [categorie, liste] of parcours) {
    for (let i = 0; i < liste.length; i++) {
      const regle = liste[i];
      if (regle === undefined) continue;
      const pointeur = `/${categorie}/${i}`;
      if (ids.has(regle.id)) return { ok: false, raison: "ID_EN_DOUBLE", pointeur: `${pointeur}/id` };
      ids.add(regle.id);
      const v = verifierValeurRegle(regle.type, regle.valeur);
      if (v !== null) return { ok: false, raison: v, pointeur: `${pointeur}/valeur` };
      const couple = `${regle.type}\u0000${regle.valeur.toUpperCase()}`;
      if (couples.has(couple)) return { ok: false, raison: "REGLE_EN_DOUBLE", pointeur };
      couples.add(couple);
    }
  }
  if (!r.segments_interdits.some((x) => x.valeur.toUpperCase() === "FASTCLIP")) {
    return { ok: false, raison: "REGLE_FASTCLIP_ABSENTE", pointeur: "/segments_interdits" };
  }
  return { ok: true, regles: r };
}

// ---------------------------------------------------------------------------------------------
// Correspondances et evaluerChemin
// ---------------------------------------------------------------------------------------------

function rangCategorie(c: CategorieExclusion): number {
  return c === "interdit" ? 0 : 1;
}

function comparerCorrespondances(a: Correspondance, b: Correspondance): number {
  if (a.index_segment !== b.index_segment) return a.index_segment - b.index_segment;
  const r = rangCategorie(a.categorie) - rangCategorie(b.categorie);
  if (r !== 0) return r;
  return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
}

/**
 * Toutes les correspondances des segments avec les règles (comparaison en majuscules), triées
 * par index de segment, puis catégorie (interdit avant secret), puis id.
 */
export function correspondancesSegments(segments: readonly string[], regles: ReglesExclusion): Correspondance[] {
  const resultat: Correspondance[] = [];
  for (let i = 0; i < segments.length; i++) {
    const segment = (segments[i] ?? "").toUpperCase();
    for (const r of regles.segments_interdits) {
      if (segment.includes(r.valeur.toUpperCase())) resultat.push({ index_segment: i, categorie: "interdit", id: r.id });
    }
    for (const r of regles.secrets) {
      const valeur = r.valeur.toUpperCase();
      const correspond =
        r.type === "nom_exact" ? segment === valeur : r.type === "prefixe" ? segment.startsWith(valeur) : segment.endsWith(valeur);
      if (correspond) resultat.push({ index_segment: i, categorie: "secret", id: r.id });
    }
  }
  return resultat.sort(comparerCorrespondances);
}

/**
 * Évaluation unique d'un chemin relatif.
 * 1. Règles invalides ou incomplètes : erreur_regles, sans évaluation du chemin.
 * 2. Syntaxe invalide : invalide.
 * 3. Aucune correspondance : autorise.
 * 4. Sinon : code CHEMIN_INTERDIT si une correspondance « interdit » existe n'importe où, sinon
 *    CHEMIN_SECRET ; racine d'exclusion = préfixe qui s'arrête au segment le moins profond ayant
 *    une correspondance, quelle que soit sa catégorie.
 */
export function evaluerChemin(cheminRelatif: unknown, regles: unknown): ResultatEvaluation {
  const verification = verifierReglesExclusion(regles);
  if (!verification.ok) {
    return {
      statut: "erreur_regles",
      code: "REGLES_EXCLUSION_INVALIDES",
      detail: { raison: verification.raison, pointeur: verification.pointeur },
    };
  }
  if (typeof cheminRelatif !== "string") {
    return { statut: "invalide", code: "CHEMIN_INVALIDE", sous_regle: "TYPE", index_segment: null };
  }
  const analyse = analyserCheminRelatif(cheminRelatif);
  if (!analyse.ok) {
    return { statut: "invalide", code: "CHEMIN_INVALIDE", sous_regle: analyse.sous_regle, index_segment: analyse.index_segment };
  }
  const correspondances = correspondancesSegments(analyse.segments, verification.regles);
  const premiere = correspondances[0];
  if (premiere === undefined) return { statut: "autorise", chemin_normalise: analyse.normalise };
  const interdite = correspondances.find((c) => c.categorie === "interdit");
  const regleCode = interdite ?? premiere;
  return {
    statut: "exclu",
    code: interdite !== undefined ? "CHEMIN_INTERDIT" : "CHEMIN_SECRET",
    categorie: regleCode.categorie,
    racine_exclusion: analyse.segments.slice(0, premiere.index_segment + 1).join("/"),
    index_racine: premiere.index_segment,
    regle_racine: { categorie: premiere.categorie, id: premiere.id },
    regle_code: { categorie: regleCode.categorie, id: regleCode.id },
    correspondances,
  };
}
