// Calcul de la politique effective d'une mission Bridge v1 (bibliothèque pure).
//
// Ordre de calcul :
//   1. configuration (profils et règles de chemins) et schémas internes ;
//   2. contexte (racine autorisée et racine de Bridge, saisies par l'utilisateur) ;
//   3. mission (schéma fermé ; donnée non fiable) ;
//   4. entrées du périmètre (écriture puis lecture), voir perimetre.ts ;
//   5. classification (jamais d'abaissement) ;
//   6. limites, APRÈS la classification : absente → plafond ; demandée ≤ plafond → valeur demandée ;
//      demandée > plafond → refus explicite. Aucun plafonnement silencieux ;
//   7. sortie déterministe, validée contre politique.schema.json.
// Les champs textuels de la mission (objectif, descriptions, notes) ne sont jamais lus par le calcul.

import schemaContexte from "./schemas/contexte.schema.json" with { type: "json" };
import schemaExclusionsLecture from "./schemas/exclusions-lecture.schema.json" with { type: "json" };
import schemaMission from "./schemas/mission.schema.json" with { type: "json" };
import schemaPolitique from "./schemas/politique.schema.json" with { type: "json" };
import schemaProfils from "./schemas/profils.schema.json" with { type: "json" };
import schemaReglesChemins from "./schemas/regles-chemins.schema.json" with { type: "json" };
import schemaReglesExclusion from "./schemas/regles-exclusion.schema.json" with { type: "json" };
import {
  analyserRacine,
  correspondancesSegments,
  verifierReglesExclusion,
  type RacineAnalysee,
  type ReglesExclusion,
} from "./chemins.ts";
import {
  classeMax,
  detecterSensibilite,
  verifierReglesClassification,
  type Classe,
  type RaisonElevation,
  type ReglesClassification,
} from "./classification.ts";
import { CODES, refus, type Refus } from "./erreurs.ts";
import { controlerEntree, type EntreeAcceptee } from "./perimetre.ts";
import { construireExclusions, type ExclusionsLecture } from "./regles-politique.ts";
import { estObjetSimple, valider, verifierSchema, type ErreurValidation } from "./validation.ts";

export const CLES_PLAFONDS = [
  "tours_claude_par_appel",
  "appels_claude",
  "appels_codex",
  "corrections",
  "duree_max_min",
  "delai_appel_claude_min",
  "delai_appel_codex_min",
] as const;
export type ClePlafond = (typeof CLES_PLAFONDS)[number];

export const CLES_INDICATEURS = ["budget_claude_usd_par_appel", "tokens_codex", "budget_global_usd"] as const;
export type CleIndicateur = (typeof CLES_INDICATEURS)[number];

export type ValidationHumaine = "lancement" | "plan" | "fin";

export interface ProfilValide {
  readonly classe: Classe;
  readonly provisoire: boolean;
  readonly plafonds: Readonly<Record<ClePlafond, number>>;
  readonly indicateurs: Readonly<Record<CleIndicateur, number>>;
  readonly validations_humaines: readonly ValidationHumaine[];
}

export interface ConfigurationValidee {
  readonly profils: { readonly version: "1"; readonly profils: readonly ProfilValide[] };
  readonly regles_chemins: {
    readonly version: "1";
    readonly exclusion: ReglesExclusion;
    readonly classification: ReglesClassification;
  };
}

export interface Politique {
  readonly version: "1";
  readonly mission_id: string;
  readonly classe_demandee: Classe;
  readonly classe_effective: Classe;
  readonly raisons_elevation: readonly RaisonElevation[];
  readonly limites: Readonly<Record<ClePlafond, number>>;
  readonly indicateurs: Readonly<Record<CleIndicateur, number>>;
  readonly indicateurs_statut: "non_bloquant";
  readonly validations_humaines: readonly ValidationHumaine[];
  readonly valeurs_provisoires: boolean;
  readonly perimetre_ecriture: readonly string[];
  readonly perimetre_lecture: readonly string[];
  readonly exclusions_lecture_obligatoires: ExclusionsLecture;
}

export type ResultatPolitique = { readonly ok: true; readonly politique: Politique } | Refus;

interface MissionValide {
  readonly version: "1";
  readonly id: string;
  readonly criteres_acceptation: ReadonlyArray<{ readonly id: string; readonly description: string }>;
  readonly perimetre: { readonly ecriture: readonly string[]; readonly lecture?: readonly string[] };
  readonly classe_demandee: Classe;
  readonly limites_demandees?: Readonly<Partial<Record<ClePlafond, number>>>;
}

const SCHEMAS_INTERNES: ReadonlyArray<readonly [string, unknown]> = [
  ["mission", schemaMission],
  ["contexte", schemaContexte],
  ["profils", schemaProfils],
  ["regles-chemins", schemaReglesChemins],
  ["regles-exclusion", schemaReglesExclusion],
  ["exclusions-lecture", schemaExclusionsLecture],
  ["politique", schemaPolitique],
];

/** Vérifie que tous les schémas du noyau respectent le sous-ensemble fermé. */
export function verifierSchemasInternes(): Refus | null {
  for (const [nom, schema] of SCHEMAS_INTERNES) {
    const e = verifierSchema(schema);
    if (e !== null) return refus(CODES.CONFIGURATION_INVALIDE, null, { schema: nom, raison: e.raison, pointeur: e.pointeur });
  }
  return null;
}

function refusConfiguration(raison: string, pointeur: string): Refus {
  return refus(CODES.CONFIGURATION_INVALIDE, null, { raison, pointeur });
}

/** Valide la configuration complète { profils, regles_chemins }. */
export function validerConfiguration(configuration: unknown): { readonly ok: true; readonly configuration: ConfigurationValidee } | Refus {
  const interne = verifierSchemasInternes();
  if (interne !== null) return interne;
  if (!estObjetSimple(configuration)) return refusConfiguration("TYPE", "");
  for (const cle of Object.keys(configuration)) {
    if (cle !== "profils" && cle !== "regles_chemins") return refusConfiguration("CHAMP_NON_PREVU", `/${cle}`);
  }
  for (const cle of ["profils", "regles_chemins"]) {
    if (!Object.hasOwn(configuration, cle)) return refusConfiguration("CHAMP_MANQUANT", `/${cle}`);
  }

  const ep = valider(schemaProfils, configuration["profils"]);
  if (ep !== null) return refusConfiguration(ep.raison, `/profils${ep.pointeur}`);
  const profils = configuration["profils"] as ConfigurationValidee["profils"];
  const classes = new Set<Classe>();
  for (let i = 0; i < profils.profils.length; i++) {
    const p = profils.profils[i];
    if (p === undefined) continue;
    const base = `/profils/profils/${i}`;
    if (classes.has(p.classe)) return refusConfiguration("CLASSE_EN_DOUBLE", `${base}/classe`);
    classes.add(p.classe);
    if (p.plafonds.delai_appel_claude_min > p.plafonds.duree_max_min) {
      return refusConfiguration("DELAI_SUPERIEUR_A_LA_DUREE", `${base}/plafonds/delai_appel_claude_min`);
    }
    if (p.plafonds.delai_appel_codex_min > p.plafonds.duree_max_min) {
      return refusConfiguration("DELAI_SUPERIEUR_A_LA_DUREE", `${base}/plafonds/delai_appel_codex_min`);
    }
    const validations = new Set(p.validations_humaines);
    if (validations.size !== p.validations_humaines.length) return refusConfiguration("VALIDATION_EN_DOUBLE", `${base}/validations_humaines`);
    if (!validations.has("lancement") || !validations.has("fin")) {
      return refusConfiguration("VALIDATIONS_INCOMPLETES", `${base}/validations_humaines`);
    }
    if (p.classe === "sensible" && !validations.has("plan")) return refusConfiguration("VALIDATION_PLAN_ABSENTE", `${base}/validations_humaines`);
  }
  if (classes.size !== 3) return refusConfiguration("CLASSES_INCOMPLETES", "/profils/profils");

  const er = valider(schemaReglesChemins, configuration["regles_chemins"]);
  if (er !== null) return refusConfiguration(er.raison, `/regles_chemins${er.pointeur}`);
  const reglesChemins = configuration["regles_chemins"] as ConfigurationValidee["regles_chemins"];
  const ve = verifierReglesExclusion(reglesChemins.exclusion);
  if (!ve.ok) return refusConfiguration(ve.raison, `/regles_chemins/exclusion${ve.pointeur}`);
  const vc = verifierReglesClassification(reglesChemins.classification);
  if (vc !== null) return refusConfiguration(vc.raison, `/regles_chemins/classification${vc.pointeur}`);

  return { ok: true, configuration: { profils, regles_chemins: reglesChemins } };
}

function segmentsMajuscules(r: RacineAnalysee): string[] {
  return [r.lecteur.toUpperCase(), ...r.segments.map((s) => s.toUpperCase())];
}

function chevauchement(a: RacineAnalysee, b: RacineAnalysee): boolean {
  const sa = segmentsMajuscules(a);
  const sb = segmentsMajuscules(b);
  const n = Math.min(sa.length, sb.length);
  for (let i = 0; i < n; i++) if (sa[i] !== sb[i]) return false;
  return true;
}

function validerContexte(contexte: unknown, regles: ReglesExclusion): { readonly ok: true; readonly racine: RacineAnalysee } | Refus {
  const e = valider(schemaContexte, contexte);
  if (e !== null) return refus(CODES.CONTEXTE_INVALIDE, null, { raison: e.raison, pointeur: e.pointeur });
  const c = contexte as { readonly racine_autorisee: string; readonly racine_bridge: string };
  const autorisee = analyserRacine(c.racine_autorisee);
  if (!autorisee.ok) return refus(CODES.CONTEXTE_INVALIDE, c.racine_autorisee, { champ: "racine_autorisee", raison: autorisee.raison });
  const bridge = analyserRacine(c.racine_bridge);
  if (!bridge.ok) return refus(CODES.CONTEXTE_INVALIDE, c.racine_bridge, { champ: "racine_bridge", raison: bridge.raison });
  const correspondances = correspondancesSegments(autorisee.racine.segments, regles);
  if (correspondances.some((x) => x.categorie === "interdit")) {
    return refus(CODES.RACINE_INTERDITE, c.racine_autorisee, { correspondances });
  }
  if (correspondances.length > 0) return refus(CODES.RACINE_SECRET, c.racine_autorisee, { correspondances });
  if (chevauchement(autorisee.racine, bridge.racine)) return refus(CODES.CHEVAUCHEMENT_BRIDGE, c.racine_autorisee, {});
  return { ok: true, racine: autorisee.racine };
}

function lireEcriture(mission: unknown): unknown {
  if (!estObjetSimple(mission)) return undefined;
  const perimetre = mission["perimetre"];
  return estObjetSimple(perimetre) ? perimetre["ecriture"] : undefined;
}

function refusMission(e: ErreurValidation, mission: unknown): Refus {
  const p = e.pointeur;
  if (p.startsWith("/limites_demandees/") && e.raison !== "CHAMP_NON_PREVU") {
    return refus(CODES.LIMITE_INVALIDE, null, { pointeur: p, raison: e.raison });
  }
  if (p === "/perimetre/ecriture") {
    const ecriture = lireEcriture(mission);
    if (e.raison === "CHAMP_MANQUANT" || (e.raison === "TAILLE_TABLEAU" && Array.isArray(ecriture) && ecriture.length === 0)) {
      return refus(CODES.PERIMETRE_ECRITURE_VIDE, null, { pointeur: p });
    }
  }
  if (e.raison === "CHAMP_NON_PREVU") return refus(CODES.CHAMP_NON_PREVU, null, { pointeur: p });
  if (e.raison === "CHAMP_MANQUANT") return refus(CODES.CHAMP_MANQUANT, null, { pointeur: p });
  if (e.raison === "VALEUR_HORS_LISTE") return refus(CODES.VALEUR_HORS_LISTE, null, { pointeur: p });
  return refus(CODES.MISSION_INVALIDE, null, { pointeur: p, raison: e.raison });
}

function comparerChemins(a: string, b: string): number {
  const ma = a.toUpperCase();
  const mb = b.toUpperCase();
  if (ma !== mb) return ma < mb ? -1 : 1;
  return a < b ? -1 : a > b ? 1 : 0;
}

/** Calcule la politique effective, ou renvoie un refus explicite. */
export function calculerPolitique(mission: unknown, contexte: unknown, configuration: unknown): ResultatPolitique {
  const conf = validerConfiguration(configuration);
  if (!conf.ok) return conf;
  const { profils, regles_chemins: reglesChemins } = conf.configuration;
  const regles = reglesChemins.exclusion;

  const ctx = validerContexte(contexte, regles);
  if (!ctx.ok) return ctx;

  const em = valider(schemaMission, mission);
  if (em !== null) return refusMission(em, mission);
  const m = mission as MissionValide;
  const identifiants = new Set<string>();
  for (const critere of m.criteres_acceptation) {
    if (identifiants.has(critere.id)) return refus(CODES.CRITERE_EN_DOUBLE, null, { id: critere.id });
    identifiants.add(critere.id);
  }

  const ecritures: EntreeAcceptee[] = [];
  for (const entree of m.perimetre.ecriture) {
    const r = controlerEntree(entree, ctx.racine, regles);
    if (!r.ok) return r;
    ecritures.push(r);
  }
  const lectures: EntreeAcceptee[] = [];
  for (const entree of m.perimetre.lecture ?? []) {
    const r = controlerEntree(entree, ctx.racine, regles);
    if (!r.ok) return r;
    lectures.push(r);
  }

  const raisons = detecterSensibilite(
    ecritures.map((e) => ({ relatif: e.relatif, segments: e.segments })),
    reglesChemins.classification,
  );
  const classeDetectee: Classe = raisons.length > 0 ? "sensible" : "simple";
  const classeEffective = classeMax(m.classe_demandee, classeDetectee);
  const profil = profils.profils.find((p) => p.classe === classeEffective);
  if (profil === undefined) return refus(CODES.ERREUR_INTERNE, null, { raison: "PROFIL_INTROUVABLE", classe: classeEffective });

  const demandes: Readonly<Partial<Record<ClePlafond, number>>> = m.limites_demandees ?? {};
  const limites = {} as Record<ClePlafond, number>;
  for (const cle of CLES_PLAFONDS) {
    const plafond = profil.plafonds[cle];
    const demande = demandes[cle];
    if (demande === undefined) {
      limites[cle] = plafond;
      continue;
    }
    if (demande > plafond) {
      return refus(CODES.LIMITE_SUPERIEURE_AU_PLAFOND, null, {
        cle,
        demande,
        plafond,
        classe_effective: classeEffective,
        apres_elevation: classeEffective !== m.classe_demandee,
      });
    }
    limites[cle] = demande;
  }

  const indicateurs = {} as Record<CleIndicateur, number>;
  for (const cle of CLES_INDICATEURS) indicateurs[cle] = profil.indicateurs[cle];

  const politique: Politique = {
    version: "1",
    mission_id: m.id,
    classe_demandee: m.classe_demandee,
    classe_effective: classeEffective,
    raisons_elevation: raisons,
    limites,
    indicateurs,
    indicateurs_statut: "non_bloquant",
    validations_humaines: [...profil.validations_humaines],
    valeurs_provisoires: profil.provisoire,
    perimetre_ecriture: ecritures.map((e) => e.absolu).sort(comparerChemins),
    perimetre_lecture: lectures.map((e) => e.absolu).sort(comparerChemins),
    exclusions_lecture_obligatoires: construireExclusions(regles),
  };

  const auto = valider(schemaPolitique, politique);
  if (auto !== null) return refus(CODES.ERREUR_INTERNE, null, { raison: auto.raison, pointeur: auto.pointeur });
  return { ok: true, politique };
}
