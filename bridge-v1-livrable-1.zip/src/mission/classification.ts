// Classification des missions Bridge v1.
//
// Classe effective = max(classe demandée, classe détectée). La détection ne produit que
// « sensible » : un chemin d'écriture est sensible s'il contient, à n'importe quelle profondeur,
// un nom de fichier sensible (dernier segment) ou un nom de dossier sensible (n'importe quel
// segment), ou s'il touche un préfixe sensible (dedans, égal ou parent, en segments entiers).
// Comparaisons en majuscules. La classe n'est jamais abaissée.

import { analyserCheminRelatif, validerSegment } from "./chemins.ts";

export type Classe = "simple" | "complexe" | "sensible";

const RANG: Readonly<Record<Classe, number>> = { simple: 0, complexe: 1, sensible: 2 };

export function classeMax(a: Classe, b: Classe): Classe {
  return RANG[b] > RANG[a] ? b : a;
}

export interface ReglesClassification {
  readonly fichiers_sensibles: readonly string[];
  readonly dossiers_sensibles: readonly string[];
  readonly prefixes_sensibles: readonly string[];
}

export type RegleSensible = "fichier_sensible" | "dossier_sensible" | "prefixe_sensible";

export interface RaisonElevation {
  readonly chemin: string;
  readonly regle: RegleSensible;
  readonly valeur: string;
}

export interface CheminAnalyse {
  readonly relatif: string;
  readonly segments: readonly string[];
}

/** Contrôle des règles de classification (configuration). */
export function verifierReglesClassification(r: ReglesClassification): { readonly raison: string; readonly pointeur: string } | null {
  const listes: ReadonlyArray<readonly [string, readonly string[]]> = [
    ["fichiers_sensibles", r.fichiers_sensibles],
    ["dossiers_sensibles", r.dossiers_sensibles],
  ];
  for (const [nom, liste] of listes) {
    for (let i = 0; i < liste.length; i++) {
      const e = validerSegment(liste[i] ?? "");
      if (e !== null) return { raison: `SEGMENT_INVALIDE:${e}`, pointeur: `/${nom}/${i}` };
    }
  }
  for (let i = 0; i < r.prefixes_sensibles.length; i++) {
    const a = analyserCheminRelatif(r.prefixes_sensibles[i] ?? "");
    if (!a.ok) return { raison: `PREFIXE_INVALIDE:${a.sous_regle}`, pointeur: `/prefixes_sensibles/${i}` };
  }
  return null;
}

function majuscules(liste: readonly string[]): string[] {
  return liste.map((s) => s.toUpperCase());
}

/** Raisons d'élévation pour les chemins d'écriture, triées de façon déterministe. */
export function detecterSensibilite(chemins: readonly CheminAnalyse[], regles: ReglesClassification): RaisonElevation[] {
  const fichiers = new Map(regles.fichiers_sensibles.map((f) => [f.toUpperCase(), f] as const));
  const dossiers = new Map(regles.dossiers_sensibles.map((d) => [d.toUpperCase(), d] as const));
  const prefixes = regles.prefixes_sensibles.map((p) => ({ texte: p, segments: majuscules(p.replace(/\\/g, "/").split("/")) }));
  const raisons: RaisonElevation[] = [];

  for (const chemin of chemins) {
    const segments = majuscules(chemin.segments);
    const dernier = segments[segments.length - 1] ?? "";
    const fichier = fichiers.get(dernier);
    if (fichier !== undefined) raisons.push({ chemin: chemin.relatif, regle: "fichier_sensible", valeur: fichier });
    const dossiersVus = new Set<string>();
    for (const segment of segments) {
      const dossier = dossiers.get(segment);
      if (dossier !== undefined && !dossiersVus.has(dossier)) {
        dossiersVus.add(dossier);
        raisons.push({ chemin: chemin.relatif, regle: "dossier_sensible", valeur: dossier });
      }
    }
    for (const prefixe of prefixes) {
      const n = Math.min(prefixe.segments.length, segments.length);
      let egaux = n > 0;
      for (let i = 0; i < n && egaux; i++) egaux = segments[i] === prefixe.segments[i];
      // Dedans (chemin plus long), égal, ou parent (chemin plus court) : sensible.
      if (egaux) raisons.push({ chemin: chemin.relatif, regle: "prefixe_sensible", valeur: prefixe.texte });
    }
  }

  return raisons.sort((a, b) => {
    const ca = a.chemin.toUpperCase();
    const cb = b.chemin.toUpperCase();
    if (ca !== cb) return ca < cb ? -1 : 1;
    if (a.chemin !== b.chemin) return a.chemin < b.chemin ? -1 : 1;
    if (a.regle !== b.regle) return a.regle < b.regle ? -1 : 1;
    return a.valeur < b.valeur ? -1 : a.valeur > b.valeur ? 1 : 0;
  });
}
