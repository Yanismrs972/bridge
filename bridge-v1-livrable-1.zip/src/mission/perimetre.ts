// Contrôle d'une entrée du périmètre (lecture ou écriture) d'une mission Bridge v1.
//
// Ordre fixe, le premier refus l'emporte :
//   1. normalisation des séparateurs ;
//   2. jokers (* ou ?) : seul → JOKER_RACINE_INTERDIT ; ailleurs que comme dernier segment entier
//      → JOKER_NON_AUTORISE ; sinon le joker final est retiré ;
//   3. evaluerChemin sur la partie littérale, dont le code est repris tel quel ;
//   4. joker final présent → MOTIF_PEUT_COUVRIR_CHEMIN_INTERDIT (tout joker est refusé en v1 : un
//      joker peut produire n'importe quel nom, y compris un nom contenant un segment interdit) ;
//   5. longueur assemblée avec la racine, puis inclusion structurelle (HORS_RACINE).
// Chaque entrée désigne UN FICHIER. Le futur orchestrateur devra refuser une entrée qui correspond
// en réalité à un dossier ou à un lien (contrôle physique, hors du noyau).

import { evaluerChemin, LONGUEUR_MAX_CHEMIN, type RacineAnalysee, type ReglesExclusion } from "./chemins.ts";
import { CODES, refus, type Refus } from "./erreurs.ts";

export interface EntreeAcceptee {
  readonly ok: true;
  readonly relatif: string;
  readonly segments: readonly string[];
  readonly absolu: string;
}

function estJoker(segment: string): boolean {
  return segment.includes("*") || segment.includes("?");
}

export function controlerEntree(entree: string, racine: RacineAnalysee, regles: ReglesExclusion): EntreeAcceptee | Refus {
  const normalise = entree.replace(/\\/g, "/");
  let litteral = normalise;
  let jokerFinal = false;

  if (estJoker(normalise)) {
    if (normalise === "*" || normalise === "**") return refus(CODES.JOKER_RACINE_INTERDIT, entree);
    const parties = normalise.split("/");
    const derniere = parties[parties.length - 1] ?? "";
    const avant = parties.slice(0, -1);
    if ((derniere !== "*" && derniere !== "**") || avant.some(estJoker)) return refus(CODES.JOKER_NON_AUTORISE, entree);
    litteral = avant.join("/");
    jokerFinal = true;
  }

  const evaluation = evaluerChemin(litteral, regles);
  if (evaluation.statut === "erreur_regles") return refus(CODES.CONFIGURATION_INVALIDE, entree, { ...evaluation.detail });
  if (evaluation.statut === "invalide") {
    return refus(CODES.CHEMIN_INVALIDE, entree, { sous_regle: evaluation.sous_regle, index_segment: evaluation.index_segment });
  }
  if (evaluation.statut === "exclu") {
    return refus(evaluation.code === "CHEMIN_INTERDIT" ? CODES.CHEMIN_INTERDIT : CODES.CHEMIN_SECRET, entree, {
      racine_exclusion: evaluation.racine_exclusion,
      regle_racine: evaluation.regle_racine,
      regle_code: evaluation.regle_code,
    });
  }
  if (jokerFinal) return refus(CODES.MOTIF_PEUT_COUVRIR_CHEMIN_INTERDIT, entree);

  const segments = evaluation.chemin_normalise.split("/");
  const absolus = [...racine.segments, ...segments];
  const absolu = `${racine.lecteur}:\\${absolus.join("\\")}`;
  if (absolu.length > LONGUEUR_MAX_CHEMIN) return refus(CODES.CHEMIN_INVALIDE, entree, { sous_regle: "CHEMIN_TROP_LONG", index_segment: null });

  // Défense supplémentaire : inclusion structurelle segment par segment, sans tenir compte de la casse.
  for (let i = 0; i < racine.segments.length; i++) {
    if ((absolus[i] ?? "").toUpperCase() !== (racine.segments[i] ?? "").toUpperCase()) return refus(CODES.HORS_RACINE, entree);
  }
  return { ok: true, relatif: evaluation.chemin_normalise, segments, absolu };
}
