// Analyse JSON stricte (Bridge v1).
//
// JSON.parse ne signale pas les clés dupliquées : il conserve la dernière valeur. Il ne peut donc
// pas détecter seul les doublons. Ce module parcourt d'abord le texte selon la grammaire JSON
// (RFC 8259), sans construire aucun objet, sans dépendance et sans exécution dynamique de code :
//   1. limites préalables (taille du texte, marque d'ordre des octets refusée) ;
//   2. grammaire stricte (virgules finales, commentaires, guillemets simples, NaN, Infinity,
//      hexadécimal, échappements invalides, contrôles non échappés, contenu après la racine) ;
//   3. clés dupliquées refusées dans chaque objet, à tous les niveaux, après décodage des
//      échappements, même si les deux valeurs sont identiques (comparaison exacte des unités
//      de code, sans pliage de casse ni normalisation) ;
//   4. profondeur maximale 32 (racine au niveau 1) et 10 000 nœuds au plus (chaque valeur JSON
//      compte : objet, tableau, chaîne, nombre, true, false, null ; les noms de clés ne comptent pas).
// Seulement si tout réussit, JSON.parse construit la valeur. Tout désaccord aboutit à un refus.

import { pointeurEnfant } from "./validation.ts";

export const TAILLE_TEXTE_MAX = 1_048_576;
export const PROFONDEUR_MAX_JSON = 32;
export const NOEUDS_MAX_JSON = 10_000;

export type SousRaisonJson = "TYPE" | "SYNTAXE" | "CLE_DUPLIQUEE" | "PROFONDEUR" | "TAILLE" | "TAILLE_TEXTE";

export interface EchecJson {
  readonly ok: false;
  readonly code: "JSON_INVALIDE";
  readonly sous_raison: SousRaisonJson;
  readonly position: number | null;
  readonly pointeur: string | null;
  readonly detail: string | null;
}

export type ResultatJson = { readonly ok: true; readonly valeur: unknown } | EchecJson;

interface Curseur {
  readonly texte: string;
  pos: number;
  noeuds: number;
}

type LectureChaine = { readonly ok: true; readonly valeur: string } | { readonly ok: false; readonly echec: EchecJson };

function echec(sous_raison: SousRaisonJson, position: number | null, pointeur: string | null, detail: string | null): EchecJson {
  return { ok: false, code: "JSON_INVALIDE", sous_raison, position, pointeur, detail };
}

function estChiffre(c: string): boolean {
  return c.length === 1 && c >= "0" && c <= "9";
}

function sauterEspaces(c: Curseur): void {
  for (;;) {
    const car = c.texte.charAt(c.pos);
    if (car === " " || car === "\t" || car === "\n" || car === "\r") c.pos += 1;
    else return;
  }
}

/** Analyse un texte JSON strict. Le paramètre n'est accepté que s'il est une chaîne. */
export function analyserJsonStrict(texte: unknown): ResultatJson {
  if (typeof texte !== "string") return echec("TYPE", null, null, null);
  if (texte.length > TAILLE_TEXTE_MAX) return echec("TAILLE_TEXTE", null, null, null);
  if (texte.charCodeAt(0) === 0xfeff) return echec("SYNTAXE", 0, null, "BOM");
  const c: Curseur = { texte, pos: 0, noeuds: 0 };
  const e = analyserValeur(c, 1, "");
  if (e !== null) return e;
  sauterEspaces(c);
  if (c.pos !== texte.length) return echec("SYNTAXE", c.pos, null, "CONTENU_APRES_RACINE");
  let valeur: unknown;
  try {
    valeur = JSON.parse(texte);
  } catch {
    return echec("SYNTAXE", null, null, "DESACCORD_ANALYSEUR");
  }
  return { ok: true, valeur };
}

function analyserValeur(c: Curseur, profondeur: number, pointeur: string): EchecJson | null {
  sauterEspaces(c);
  if (c.pos >= c.texte.length) return echec("SYNTAXE", c.pos, pointeur, "FIN_INATTENDUE");
  if (profondeur > PROFONDEUR_MAX_JSON) return echec("PROFONDEUR", c.pos, pointeur, null);
  c.noeuds += 1;
  if (c.noeuds > NOEUDS_MAX_JSON) return echec("TAILLE", c.pos, pointeur, null);
  const car = c.texte.charAt(c.pos);
  if (car === "{") return analyserObjet(c, profondeur, pointeur);
  if (car === "[") return analyserTableau(c, profondeur, pointeur);
  if (car === '"') {
    const lecture = lireChaine(c, pointeur);
    return lecture.ok ? null : lecture.echec;
  }
  if (car === "t") return lireLitteral(c, "true", pointeur);
  if (car === "f") return lireLitteral(c, "false", pointeur);
  if (car === "n") return lireLitteral(c, "null", pointeur);
  if (car === "-" || estChiffre(car)) return lireNombre(c, pointeur);
  return echec("SYNTAXE", c.pos, pointeur, "CARACTERE_INATTENDU");
}

function analyserObjet(c: Curseur, profondeur: number, pointeur: string): EchecJson | null {
  c.pos += 1;
  const cles = new Set<string>();
  sauterEspaces(c);
  if (c.texte.charAt(c.pos) === "}") {
    c.pos += 1;
    return null;
  }
  for (;;) {
    sauterEspaces(c);
    if (c.texte.charAt(c.pos) !== '"') return echec("SYNTAXE", c.pos, pointeur, "CLE_ATTENDUE");
    const cle = lireChaine(c, pointeur);
    if (!cle.ok) return cle.echec;
    const pointeurCle = pointeurEnfant(pointeur, cle.valeur);
    if (cles.has(cle.valeur)) return echec("CLE_DUPLIQUEE", c.pos, pointeurCle, null);
    cles.add(cle.valeur);
    sauterEspaces(c);
    if (c.texte.charAt(c.pos) !== ":") return echec("SYNTAXE", c.pos, pointeurCle, "DEUX_POINTS_ATTENDUS");
    c.pos += 1;
    const e = analyserValeur(c, profondeur + 1, pointeurCle);
    if (e !== null) return e;
    sauterEspaces(c);
    const separateur = c.texte.charAt(c.pos);
    if (separateur === ",") {
      c.pos += 1;
      continue;
    }
    if (separateur === "}") {
      c.pos += 1;
      return null;
    }
    return echec("SYNTAXE", c.pos, pointeur, "SEPARATEUR_ATTENDU");
  }
}

function analyserTableau(c: Curseur, profondeur: number, pointeur: string): EchecJson | null {
  c.pos += 1;
  sauterEspaces(c);
  if (c.texte.charAt(c.pos) === "]") {
    c.pos += 1;
    return null;
  }
  let index = 0;
  for (;;) {
    const e = analyserValeur(c, profondeur + 1, pointeurEnfant(pointeur, index));
    if (e !== null) return e;
    index += 1;
    sauterEspaces(c);
    const separateur = c.texte.charAt(c.pos);
    if (separateur === ",") {
      c.pos += 1;
      continue;
    }
    if (separateur === "]") {
      c.pos += 1;
      return null;
    }
    return echec("SYNTAXE", c.pos, pointeur, "SEPARATEUR_ATTENDU");
  }
}

function lireChaine(c: Curseur, pointeur: string): LectureChaine {
  const t = c.texte;
  let p = c.pos + 1;
  let resultat = "";
  for (;;) {
    if (p >= t.length) return { ok: false, echec: echec("SYNTAXE", p, pointeur, "CHAINE_NON_TERMINEE") };
    const code = t.charCodeAt(p);
    if (code === 0x22) {
      c.pos = p + 1;
      return { ok: true, valeur: resultat };
    }
    if (code < 0x20) return { ok: false, echec: echec("SYNTAXE", p, pointeur, "CONTROLE_NON_ECHAPPE") };
    if (code === 0x5c) {
      const e = t.charAt(p + 1);
      if (e === '"') resultat += '"';
      else if (e === "\\") resultat += "\\";
      else if (e === "/") resultat += "/";
      else if (e === "b") resultat += "\b";
      else if (e === "f") resultat += "\f";
      else if (e === "n") resultat += "\n";
      else if (e === "r") resultat += "\r";
      else if (e === "t") resultat += "\t";
      else if (e === "u") {
        const hex = t.slice(p + 2, p + 6);
        if (!/^[0-9A-Fa-f]{4}$/u.test(hex)) return { ok: false, echec: echec("SYNTAXE", p, pointeur, "ECHAPPEMENT_INVALIDE") };
        resultat += String.fromCharCode(Number.parseInt(hex, 16));
        p += 6;
        continue;
      } else return { ok: false, echec: echec("SYNTAXE", p, pointeur, "ECHAPPEMENT_INVALIDE") };
      p += 2;
      continue;
    }
    resultat += t.charAt(p);
    p += 1;
  }
}

function lireLitteral(c: Curseur, mot: string, pointeur: string): EchecJson | null {
  if (c.texte.startsWith(mot, c.pos)) {
    c.pos += mot.length;
    return null;
  }
  return echec("SYNTAXE", c.pos, pointeur, "LITTERAL_INVALIDE");
}

function lireNombre(c: Curseur, pointeur: string): EchecJson | null {
  const t = c.texte;
  let p = c.pos;
  if (t.charAt(p) === "-") p += 1;
  if (t.charAt(p) === "0") p += 1;
  else if (estChiffre(t.charAt(p)) && t.charAt(p) !== "0") {
    while (estChiffre(t.charAt(p))) p += 1;
  } else return echec("SYNTAXE", p, pointeur, "NOMBRE_INVALIDE");
  if (t.charAt(p) === ".") {
    p += 1;
    if (!estChiffre(t.charAt(p))) return echec("SYNTAXE", p, pointeur, "NOMBRE_INVALIDE");
    while (estChiffre(t.charAt(p))) p += 1;
  }
  if (t.charAt(p) === "e" || t.charAt(p) === "E") {
    p += 1;
    if (t.charAt(p) === "+" || t.charAt(p) === "-") p += 1;
    if (!estChiffre(t.charAt(p))) return echec("SYNTAXE", p, pointeur, "NOMBRE_INVALIDE");
    while (estChiffre(t.charAt(p))) p += 1;
  }
  c.pos = p;
  return null;
}
