// Validateur d'un sous-ensemble FERMÉ de JSON Schema (Bridge v1).
//
// Mots-clés pris en charge : $schema (une seule valeur), title, description, type, properties,
// required, additionalProperties (obligatoirement false), items (schéma unique), minItems,
// maxItems, enum, const, minLength, maxLength, pattern, minimum, maximum.
// Tout autre mot-clé rend le schéma invalide : SCHEMA_MOT_CLE_NON_PRIS_EN_CHARGE.
// Règles imposées aux schémas : tout objet est fermé, toute chaîne a un maxLength, tout tableau a
// un maxItems et un items. Le mot-clé type est obligatoire dans chaque (sous-)schéma.

export const DIALECTE_SCHEMA = "https://json-schema.org/draft/2020-12/schema";

const MOTS_CLES: ReadonlySet<string> = new Set([
  "$schema",
  "title",
  "description",
  "type",
  "properties",
  "required",
  "additionalProperties",
  "items",
  "minItems",
  "maxItems",
  "enum",
  "const",
  "minLength",
  "maxLength",
  "pattern",
  "minimum",
  "maximum",
]);

const TYPES_JSON: ReadonlySet<string> = new Set(["object", "array", "string", "integer", "number", "boolean", "null"]);
const MAX_VALEURS_ENUM = 256;

export interface ErreurValidation {
  readonly pointeur: string;
  readonly raison: string;
}

export function estObjetSimple(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

// Pointeur JSON (RFC 6901) : « ~ » devient « ~0 », « / » devient « ~1 ».
export function pointeurEnfant(parent: string, cle: string | number): string {
  const segment = typeof cle === "number" ? String(cle) : cle.replace(/~/g, "~0").replace(/\//g, "~1");
  return `${parent}/${segment}`;
}

export function longueurEnPointsDeCode(s: string): number {
  let n = 0;
  for (const _caractere of s) n += 1;
  return n;
}

function possede(o: Record<string, unknown>, cle: string): boolean {
  return Object.hasOwn(o, cle);
}

function erreur(pointeur: string, raison: string): ErreurValidation {
  return { pointeur, raison };
}

function estEntierNonNegatif(v: unknown): v is number {
  return typeof v === "number" && Number.isInteger(v) && v >= 0;
}

function estNombreFini(v: unknown): v is number {
  return typeof v === "number" && Number.isFinite(v);
}

function estPrimitifJson(v: unknown): boolean {
  return v === null || typeof v === "string" || typeof v === "boolean" || estNombreFini(v);
}

function lireTypes(v: unknown): string[] | null {
  if (typeof v === "string") return TYPES_JSON.has(v) ? [v] : null;
  if (Array.isArray(v) && v.length > 0) {
    const types: string[] = [];
    for (const t of v) {
      if (typeof t !== "string" || !TYPES_JSON.has(t) || types.includes(t)) return null;
      types.push(t);
    }
    return types;
  }
  return null;
}

// Mémorisation déterministe des expressions régulières compilées (drapeau u, non global).
const cacheMotifs = new Map<string, RegExp>();

function compilerMotif(motif: string): RegExp | null {
  const existant = cacheMotifs.get(motif);
  if (existant !== undefined) return existant;
  try {
    const expression = new RegExp(motif, "u");
    cacheMotifs.set(motif, expression);
    return expression;
  } catch {
    return null;
  }
}

/** Vérifie qu'un schéma n'utilise que le sous-ensemble fermé, avec ses règles imposées. */
export function verifierSchema(schema: unknown, pointeur = ""): ErreurValidation | null {
  if (!estObjetSimple(schema)) return erreur(pointeur, "SCHEMA_NON_OBJET");
  for (const cle of Object.keys(schema)) {
    if (!MOTS_CLES.has(cle)) return erreur(pointeurEnfant(pointeur, cle), "SCHEMA_MOT_CLE_NON_PRIS_EN_CHARGE");
  }
  if (possede(schema, "$schema") && schema["$schema"] !== DIALECTE_SCHEMA) {
    return erreur(pointeurEnfant(pointeur, "$schema"), "SCHEMA_DIALECTE_INVALIDE");
  }
  for (const cle of ["title", "description"]) {
    if (possede(schema, cle) && typeof schema[cle] !== "string") {
      return erreur(pointeurEnfant(pointeur, cle), "SCHEMA_ANNOTATION_INVALIDE");
    }
  }
  const types = lireTypes(schema["type"]);
  if (types === null) return erreur(pointeurEnfant(pointeur, "type"), "SCHEMA_TYPE_INVALIDE");

  // Objets : fermés, propriétés déclarées, required cohérent.
  if (types.includes("object")) {
    if (schema["additionalProperties"] !== false) {
      return erreur(pointeurEnfant(pointeur, "additionalProperties"), "SCHEMA_OBJET_NON_FERME");
    }
    const proprietes = schema["properties"];
    if (!estObjetSimple(proprietes)) return erreur(pointeurEnfant(pointeur, "properties"), "SCHEMA_PROPRIETES_ABSENTES");
    if (possede(schema, "required")) {
      const requis = schema["required"];
      if (!Array.isArray(requis)) return erreur(pointeurEnfant(pointeur, "required"), "SCHEMA_REQUIRED_INVALIDE");
      const vus = new Set<string>();
      for (const r of requis) {
        if (typeof r !== "string" || vus.has(r) || !possede(proprietes, r)) {
          return erreur(pointeurEnfant(pointeur, "required"), "SCHEMA_REQUIRED_INVALIDE");
        }
        vus.add(r);
      }
    }
    const pointeurProprietes = pointeurEnfant(pointeur, "properties");
    for (const nom of Object.keys(proprietes)) {
      const e = verifierSchema(proprietes[nom], pointeurEnfant(pointeurProprietes, nom));
      if (e !== null) return e;
    }
  } else if (possede(schema, "properties") || possede(schema, "required") || possede(schema, "additionalProperties")) {
    return erreur(pointeur, "SCHEMA_MOT_CLE_INCOHERENT");
  }

  // Tableaux : bornés, schéma d'éléments unique.
  if (types.includes("array")) {
    const max = schema["maxItems"];
    if (!estEntierNonNegatif(max)) return erreur(pointeurEnfant(pointeur, "maxItems"), "SCHEMA_TABLEAU_NON_BORNE");
    if (possede(schema, "minItems")) {
      const min = schema["minItems"];
      if (!estEntierNonNegatif(min) || min > max) return erreur(pointeurEnfant(pointeur, "minItems"), "SCHEMA_BORNES_INVALIDES");
    }
    if (!possede(schema, "items")) return erreur(pointeurEnfant(pointeur, "items"), "SCHEMA_ITEMS_ABSENT");
    const e = verifierSchema(schema["items"], pointeurEnfant(pointeur, "items"));
    if (e !== null) return e;
  } else if (possede(schema, "items") || possede(schema, "minItems") || possede(schema, "maxItems")) {
    return erreur(pointeur, "SCHEMA_MOT_CLE_INCOHERENT");
  }

  // Chaînes : bornées ; motif compilable.
  if (types.includes("string")) {
    const max = schema["maxLength"];
    if (!estEntierNonNegatif(max)) return erreur(pointeurEnfant(pointeur, "maxLength"), "SCHEMA_CHAINE_NON_BORNEE");
    if (possede(schema, "minLength")) {
      const min = schema["minLength"];
      if (!estEntierNonNegatif(min) || min > max) return erreur(pointeurEnfant(pointeur, "minLength"), "SCHEMA_BORNES_INVALIDES");
    }
    if (possede(schema, "pattern")) {
      const motif = schema["pattern"];
      if (typeof motif !== "string" || compilerMotif(motif) === null) {
        return erreur(pointeurEnfant(pointeur, "pattern"), "SCHEMA_MOTIF_INVALIDE");
      }
    }
  } else if (possede(schema, "minLength") || possede(schema, "maxLength") || possede(schema, "pattern")) {
    return erreur(pointeur, "SCHEMA_MOT_CLE_INCOHERENT");
  }

  // Nombres.
  if (types.includes("integer") || types.includes("number")) {
    const min = schema["minimum"];
    const max = schema["maximum"];
    if (possede(schema, "minimum") && !estNombreFini(min)) return erreur(pointeurEnfant(pointeur, "minimum"), "SCHEMA_BORNES_INVALIDES");
    if (possede(schema, "maximum") && !estNombreFini(max)) return erreur(pointeurEnfant(pointeur, "maximum"), "SCHEMA_BORNES_INVALIDES");
    if (estNombreFini(min) && estNombreFini(max) && min > max) return erreur(pointeur, "SCHEMA_BORNES_INVALIDES");
  } else if (possede(schema, "minimum") || possede(schema, "maximum")) {
    return erreur(pointeur, "SCHEMA_MOT_CLE_INCOHERENT");
  }

  if (possede(schema, "enum")) {
    const liste = schema["enum"];
    if (!Array.isArray(liste) || liste.length === 0 || liste.length > MAX_VALEURS_ENUM || !liste.every((v) => estPrimitifJson(v))) {
      return erreur(pointeurEnfant(pointeur, "enum"), "SCHEMA_ENUM_INVALIDE");
    }
  }
  if (possede(schema, "const") && !estPrimitifJson(schema["const"])) {
    return erreur(pointeurEnfant(pointeur, "const"), "SCHEMA_CONST_INVALIDE");
  }
  return null;
}

function correspondType(type: string, v: unknown): boolean {
  switch (type) {
    case "object":
      return estObjetSimple(v);
    case "array":
      return Array.isArray(v);
    case "string":
      return typeof v === "string";
    case "integer":
      return typeof v === "number" && Number.isInteger(v);
    case "number":
      return estNombreFini(v);
    case "boolean":
      return typeof v === "boolean";
    case "null":
      return v === null;
    default:
      return false;
  }
}

/**
 * Valide une valeur contre un schéma déjà vérifié par verifierSchema.
 * Renvoie la première erreur rencontrée (ordre déterministe), ou null.
 */
export function valider(schema: unknown, valeur: unknown, pointeur = ""): ErreurValidation | null {
  if (!estObjetSimple(schema)) return erreur(pointeur, "SCHEMA_NON_VERIFIE");
  const types = lireTypes(schema["type"]);
  if (types === null) return erreur(pointeur, "SCHEMA_NON_VERIFIE");
  if (!types.some((t) => correspondType(t, valeur))) return erreur(pointeur, "TYPE");

  if (possede(schema, "enum")) {
    const liste = schema["enum"];
    if (!Array.isArray(liste) || !liste.some((x) => x === valeur)) return erreur(pointeur, "VALEUR_HORS_LISTE");
  }
  if (possede(schema, "const") && schema["const"] !== valeur) return erreur(pointeur, "CONST");

  if (typeof valeur === "string") {
    const n = longueurEnPointsDeCode(valeur);
    const max = schema["maxLength"];
    const min = schema["minLength"];
    if (typeof max === "number" && n > max) return erreur(pointeur, "LONGUEUR");
    if (typeof min === "number" && n < min) return erreur(pointeur, "LONGUEUR");
    const motif = schema["pattern"];
    if (typeof motif === "string") {
      const expression = compilerMotif(motif);
      if (expression === null || !expression.test(valeur)) return erreur(pointeur, "MOTIF");
    }
  }

  if (typeof valeur === "number") {
    const min = schema["minimum"];
    const max = schema["maximum"];
    if (typeof min === "number" && valeur < min) return erreur(pointeur, "BORNE");
    if (typeof max === "number" && valeur > max) return erreur(pointeur, "BORNE");
  }

  if (Array.isArray(valeur)) {
    const max = schema["maxItems"];
    const min = schema["minItems"];
    if (typeof max === "number" && valeur.length > max) return erreur(pointeur, "TAILLE_TABLEAU");
    if (typeof min === "number" && valeur.length < min) return erreur(pointeur, "TAILLE_TABLEAU");
    for (let i = 0; i < valeur.length; i++) {
      const e = valider(schema["items"], valeur[i], pointeurEnfant(pointeur, i));
      if (e !== null) return e;
    }
  }

  if (estObjetSimple(valeur)) {
    const proprietes = schema["properties"];
    if (!estObjetSimple(proprietes)) return erreur(pointeur, "SCHEMA_NON_VERIFIE");
    for (const cle of Object.keys(valeur)) {
      if (!possede(proprietes, cle)) return erreur(pointeurEnfant(pointeur, cle), "CHAMP_NON_PREVU");
    }
    const requis = schema["required"];
    if (Array.isArray(requis)) {
      for (const r of requis) {
        if (typeof r === "string" && !possede(valeur, r)) return erreur(pointeurEnfant(pointeur, r), "CHAMP_MANQUANT");
      }
    }
    for (const cle of Object.keys(valeur)) {
      const e = valider(proprietes[cle], valeur[cle], pointeurEnfant(pointeur, cle));
      if (e !== null) return e;
    }
  }
  return null;
}
