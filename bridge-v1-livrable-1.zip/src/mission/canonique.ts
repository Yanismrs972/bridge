/* CONTRAT-DEBUT
 * Contrat de serialiserCanonique (forme « jcs-restreint-v1 », inspirée de RFC 8785).
 *
 * Garantie : le comportement n'est garanti que pour des ARBRES DE DONNÉES INERTES conformes
 * au domaine suivant :
 *  - chaînes primitives sans surrogate UTF-16 isolée (un objet String est refusé) ;
 *  - objets dont le prototype est exactement Object.prototype ou null, dont toutes les clés
 *    propres (Reflect.ownKeys) sont des chaînes, et dont chaque propriété est une propriété
 *    de données énumérable, sans accesseur ;
 *  - tableaux dont le prototype est exactement Array.prototype, denses, dont les clés propres
 *    sont exactement "0" à "length-1" puis "length", sans clé symbolique ni propriété
 *    supplémentaire, chaque élément étant une propriété de données énumérable ;
 *  - structure en arbre : aucune référence circulaire ni partagée ;
 *  - profondeur maximale 32 (racine au niveau 1) et 10 000 nœuds au plus.
 *
 * Comptage des nœuds : chaque objet (vide compris), chaque tableau (vide compris) et chaque
 * valeur chaîne compte pour un nœud ; la racine compte ; les noms de propriétés ne comptent
 * pas. Parcours en profondeur, préfixe : propriétés dans l'ordre canonique, éléments par index
 * croissant. Pour un même nœud, les contrôles de type, de prototype et de descripteurs passent
 * avant son comptage ; une référence circulaire ou partagée est détectée avant tout nouveau
 * comptage. Le refus TAILLE intervient dès que le 10 001e nœud est rencontré.
 *
 * Entrées hors contrat : les objets Proxy, et tout objet dont les opérations de réflexion
 * (Reflect.ownKeys, Object.getOwnPropertyDescriptor, Object.getPrototypeOf, Array.isArray)
 * déclenchent des effets de bord ou peuvent renvoyer des résultats incohérents. Le noyau ne
 * peut pas détecter tous les Proxy de façon fiable et ne le prétend pas.
 *
 * Précondition : les appelants, en particulier le futur orchestrateur, ne transmettent que
 * des données issues d'un texte JSON analysé et validé par analyserJsonStrict, jamais un objet
 * arbitraire construit en mémoire.
 *
 * Les valeurs sont lues par leur descripteur (jamais par objet[cle]) : aucun accesseur n'est
 * déclenché. Toute non-conformité produit NON_CANONISABLE avec une sous-raison et un pointeur
 * JSON ; aucune sérialisation partielle n'est jamais renvoyée.
 *
 * Sérialisation : propriétés triées par unités de code UTF-16 ; ordre des tableaux conservé ;
 * aucun espace ; dans les chaînes, seuls les guillemets, la barre oblique inverse et U+0000 à
 * U+001F sont échappés (formes courtes b t n f r, sinon u00xx en hexadécimal minuscule) ;
 * aucune normalisation Unicode. Encodage attendu par l'appelant : UTF-8 sans BOM.
 * L'empreinte SHA-256 est calculée par l'orchestrateur, hors du noyau.
CONTRAT-FIN */

import { pointeurEnfant } from "./validation.ts";

export const PROFONDEUR_MAX_CANONIQUE = 32;
export const NOEUDS_MAX_CANONIQUE = 10_000;
export const FORME_CANONIQUE = "jcs-restreint-v1";

export type SousRaisonCanonique =
  | "TYPE"
  | "PROTOTYPE"
  | "SYMBOLE"
  | "ACCESSEUR"
  | "NON_ENUMERABLE"
  | "TROU"
  | "PROPRIETE_TABLEAU"
  | "CIRCULAIRE"
  | "PARTAGE"
  | "PROFONDEUR"
  | "TAILLE"
  | "SURROGATE";

export type ResultatCanonique =
  | { readonly ok: true; readonly texte: string }
  | { readonly ok: false; readonly code: "NON_CANONISABLE"; readonly sous_raison: SousRaisonCanonique; readonly pointeur: string };

class RefusCanonique extends Error {
  readonly sousRaison: SousRaisonCanonique;
  readonly pointeur: string;
  constructor(sousRaison: SousRaisonCanonique, pointeur: string) {
    super(sousRaison);
    this.sousRaison = sousRaison;
    this.pointeur = pointeur;
  }
}

interface Etat {
  noeuds: number;
  readonly vus: Set<object>;
  readonly ancetres: Set<object>;
}

const HEXADECIMAL = "0123456789abcdef";
const INDEX_TABLEAU = /^(?:0|[1-9][0-9]*)$/u;

export function serialiserCanonique(valeur: unknown): ResultatCanonique {
  const etat: Etat = { noeuds: 0, vus: new Set(), ancetres: new Set() };
  try {
    return { ok: true, texte: serialiserNoeud(valeur, 1, "", etat) };
  } catch (e) {
    if (e instanceof RefusCanonique) {
      return { ok: false, code: "NON_CANONISABLE", sous_raison: e.sousRaison, pointeur: e.pointeur };
    }
    throw e;
  }
}

/** Vrai si la chaîne contient une surrogate UTF-16 isolée. */
export function contientSurrogateIsolee(s: string): boolean {
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    if (c >= 0xd800 && c <= 0xdbff) {
      const suivant = i + 1 < s.length ? s.charCodeAt(i + 1) : -1;
      if (suivant < 0xdc00 || suivant > 0xdfff) return true;
      i += 1;
    } else if (c >= 0xdc00 && c <= 0xdfff) {
      return true;
    }
  }
  return false;
}

/** Représentation canonique d'une chaîne (sans contrôle des surrogates). */
export function chaineCanonique(s: string): string {
  let r = '"';
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    if (c === 0x22) r += '\\"';
    else if (c === 0x5c) r += "\\\\";
    else if (c === 0x08) r += "\\b";
    else if (c === 0x09) r += "\\t";
    else if (c === 0x0a) r += "\\n";
    else if (c === 0x0c) r += "\\f";
    else if (c === 0x0d) r += "\\r";
    else if (c < 0x20) r += "\\u00" + HEXADECIMAL.charAt(c >> 4) + HEXADECIMAL.charAt(c & 0xf);
    else r += s.charAt(i);
  }
  return r + '"';
}

function compter(profondeur: number, pointeur: string, etat: Etat): void {
  if (profondeur > PROFONDEUR_MAX_CANONIQUE) throw new RefusCanonique("PROFONDEUR", pointeur);
  etat.noeuds += 1;
  if (etat.noeuds > NOEUDS_MAX_CANONIQUE) throw new RefusCanonique("TAILLE", pointeur);
}

function lireDonnee(cible: object, cle: string, pointeur: string, absence: SousRaisonCanonique): unknown {
  const d = Object.getOwnPropertyDescriptor(cible, cle);
  if (d === undefined) throw new RefusCanonique(absence, pointeur);
  if (!Object.hasOwn(d, "value")) throw new RefusCanonique("ACCESSEUR", pointeur);
  if (d.enumerable !== true) throw new RefusCanonique("NON_ENUMERABLE", pointeur);
  return d.value;
}

function serialiserNoeud(v: unknown, profondeur: number, pointeur: string, etat: Etat): string {
  if (typeof v === "string") {
    if (contientSurrogateIsolee(v)) throw new RefusCanonique("SURROGATE", pointeur);
    compter(profondeur, pointeur, etat);
    return chaineCanonique(v);
  }
  if (typeof v !== "object" || v === null) throw new RefusCanonique("TYPE", pointeur);
  if (etat.vus.has(v)) throw new RefusCanonique(etat.ancetres.has(v) ? "CIRCULAIRE" : "PARTAGE", pointeur);

  if (Array.isArray(v)) {
    if (Object.getPrototypeOf(v) !== Array.prototype) throw new RefusCanonique("PROTOTYPE", pointeur);
    const cles = Reflect.ownKeys(v);
    const descripteurLongueur = Object.getOwnPropertyDescriptor(v, "length");
    if (
      descripteurLongueur === undefined ||
      !Object.hasOwn(descripteurLongueur, "value") ||
      typeof descripteurLongueur.value !== "number"
    ) {
      throw new RefusCanonique("TYPE", pointeur);
    }
    const longueur: number = descripteurLongueur.value;
    let indices = 0;
    for (const cle of cles) {
      if (typeof cle !== "string") throw new RefusCanonique("SYMBOLE", pointeur);
      if (cle === "length") continue;
      if (!INDEX_TABLEAU.test(cle) || Number(cle) >= longueur) {
        throw new RefusCanonique("PROPRIETE_TABLEAU", pointeurEnfant(pointeur, cle));
      }
      indices += 1;
    }
    if (indices !== longueur) {
      // Premier index manquant : il est forcément inférieur ou égal au nombre d'indices présents.
      let manquant = 0;
      while (manquant < longueur && Object.hasOwn(v, String(manquant))) manquant += 1;
      throw new RefusCanonique("TROU", pointeurEnfant(pointeur, manquant));
    }
    const elements: unknown[] = [];
    for (let i = 0; i < longueur; i++) elements.push(lireDonnee(v, String(i), pointeurEnfant(pointeur, i), "TROU"));
    compter(profondeur, pointeur, etat);
    etat.vus.add(v);
    etat.ancetres.add(v);
    const parties: string[] = [];
    for (let i = 0; i < elements.length; i++) {
      parties.push(serialiserNoeud(elements[i], profondeur + 1, pointeurEnfant(pointeur, i), etat));
    }
    etat.ancetres.delete(v);
    return "[" + parties.join(",") + "]";
  }

  const prototype: unknown = Object.getPrototypeOf(v);
  if (prototype === String.prototype || prototype === Number.prototype || prototype === Boolean.prototype) {
    throw new RefusCanonique("TYPE", pointeur);
  }
  if (prototype !== Object.prototype && prototype !== null) throw new RefusCanonique("PROTOTYPE", pointeur);
  const cles = Reflect.ownKeys(v);
  const noms: string[] = [];
  for (const cle of cles) {
    if (typeof cle !== "string") throw new RefusCanonique("SYMBOLE", pointeur);
    noms.push(cle);
  }
  const valeurs = new Map<string, unknown>();
  for (const nom of noms) {
    const pointeurNom = pointeurEnfant(pointeur, nom);
    if (contientSurrogateIsolee(nom)) throw new RefusCanonique("SURROGATE", pointeurNom);
    valeurs.set(nom, lireDonnee(v, nom, pointeurNom, "TYPE"));
  }
  compter(profondeur, pointeur, etat);
  etat.vus.add(v);
  etat.ancetres.add(v);
  noms.sort();
  const parties: string[] = [];
  for (const nom of noms) {
    const texte = serialiserNoeud(valeurs.get(nom), profondeur + 1, pointeurEnfant(pointeur, nom), etat);
    parties.push(chaineCanonique(nom) + ":" + texte);
  }
  etat.ancetres.delete(v);
  return "{" + parties.join(",") + "}";
}
